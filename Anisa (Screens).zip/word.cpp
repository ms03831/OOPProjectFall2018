#include "word.h"

word::word()
{
    //chr = NULL;
}

word::word(std::string fileName, LTexture* sheetTexture, int x, int y)
{
    this -> textTexture = sheetTexture;
    setPosition(x, y);
    setText(fileName);
}

void word::render(SDL_Renderer* gRenderer)
{
    for (int i = 0; i < this -> renderText.length(); i++)
    {
        chr[i].render(gRenderer);
    }
}

void word::setText(std::string myChar)
{
    this -> renderText = myChar;
    chr = new character[myChar.length()];
    int j = 0, k = 0;
    for (int i = 0; i < this -> renderText.length(); i++)
    {
        j += 35;
        chr[i].setTexture(this -> textTexture, myChar[i], j, this -> x, this -> y);
        k += 100;
    }

}

void word::setPosition(int x, int y)
{
    this -> x = x;
    this -> y = y;

}

int word::getTextLength()
{
    int i = 0, len = 0;
    while (renderText[i] != NULL)
    {
        len += 1;
        i++;
    }
    return len;
}

word::~word()
{

}
