#ifndef SPLASH_SCREEN_H_INCLUDED
#define SPLASH_SCREEN_H_INCLUDED
#pragma once
#include "Screen.h"

class splash_screen : public Screen
{
public:
    splash_screen();
    splash_screen(LTexture*);
    ~splash_screen();
    void render(SDL_Renderer*);

private:
    LTexture* splash_bg;

};



#endif // SPLASH_SCREEN_H_INCLUDED
