#include "Map.h"
Map::Map()
{

}

Map::Map(LTexture* mapTexture, LTexture* tileTexture)
{
    gameMap = mapTexture;
    this -> platformTexture = tileTexture;
    platform = new Tile(platformTexture);
    gTileClip.x = 0;
    gTileClip.y = 0;
    gTileClip.w = 32;
    gTileClip.h = 32;
}

void Map::render(SDL_Renderer* gRenderer)
{
    int i = 0, j = 0;
    while (i < 800)
    {
        j = 0;
        while (j < 600)
        {
            gameMap->render(i, j, gRenderer, &gTileClip);
            platform -> render(gRenderer);
            j+= 30;
        }
        i += 30;
    }
}

Map::~Map()
{

}
