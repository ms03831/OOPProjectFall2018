#ifndef WORD_H_INCLUDED
#define WORD_H_INCLUDED
#pragma once
#include "character.h"

class word
{
public:
    word();
    ~word();
    word(std::string, LTexture*, int, int);
    void render(SDL_Renderer*);
    void setText(std::string);
    void setPosition(int, int);
    int getTextLength();

private:
    int x, y;
    int position;
    std::string renderText;
    LTexture* textTexture;
    character* chr;

};


#endif // WORD_H_INCLUDED
