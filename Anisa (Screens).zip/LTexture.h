#ifndef LTEXTURE_H_INCLUDED
#define LTEXTURE_H_INCLUDED
#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include <iostream>
#include <string>
#include <stdio.h>

class LTexture
{
public:
    LTexture();
    ~LTexture();
    bool loadFromFile(std::string, SDL_Renderer*);
    void render(int x, int y, SDL_Renderer* gRenderer, SDL_Rect* clip = NULL);
    int getWidth();
    int getHeight();

private:
    int width;
    int height;
    SDL_Texture* texture;

};



#endif // LTEXTURE_H_INCLUDED
