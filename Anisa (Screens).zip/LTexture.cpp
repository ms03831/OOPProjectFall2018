#include "LTexture.h"

LTexture::LTexture()
{
    texture = NULL;
    width = 0;
    height = 0;
}

bool LTexture::loadFromFile(std::string fileName, SDL_Renderer* renderer )
{
    SDL_Surface* surf = IMG_Load(fileName.c_str());
    SDL_Texture* newTexture = SDL_CreateTextureFromSurface(renderer, surf);

    if( surf == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", fileName.c_str(), IMG_GetError() );
	}
    else
    {
        if( newTexture == NULL )
        {
            printf( "Unable to create texture from %s! SDL Error: %s\n", fileName.c_str(), SDL_GetError() );
        }
        else
        {
            width = surf -> w;
            height = surf ->h;
        }
    }

    SDL_FreeSurface(surf);
    texture = newTexture;

    return texture != NULL;
}

void LTexture::render(int x, int y, SDL_Renderer* myRend, SDL_Rect* clip)
{
    SDL_Rect pos = { x, y, width, height };

    if( clip != NULL )
    {
        pos.w = clip-> w;
        pos.h = clip-> h;
        SDL_RenderCopy(myRend, texture, clip, &pos );
    }
    else if (clip == NULL)
    {
        SDL_RenderCopy(myRend, texture, NULL, NULL);
    }

}

int LTexture::getHeight()
{
    return height;
}

int LTexture::getWidth()
{
    return width;
}

LTexture::~LTexture()
{

}
