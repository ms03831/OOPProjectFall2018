#include <iostream>
#include "SDL.h"
#include "SDL_image.h"
#include <stdio.h>
#include "LTexture.h"
#include "character.h"
#include "word.h"
#include "button.h"
#include "Screen.h"
#include "main_menu.h"
#include "Map.h"
#include "Tile.h"
#include "splash_screen.h"

using namespace std;

bool init(string, int, int, int, int, bool);
bool loadMedia();
void render(SDL_Renderer*);
void clean();

SDL_Window* window = NULL;
SDL_Renderer* gRenderer;
LTexture fontTexture;
LTexture mainTexture;
LTexture buttonTexture;
LTexture tileTexture;
LTexture platformTexture;
LTexture splashTexture;

int SCREEN_WIDTH = 800;
int SCREEN_HEIGHT = 600;

int main(int argc, char* argv[])
{
    bool isRunning;
    isRunning = init("Pasbaan e Zafar", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, true);
    if (loadMedia() == false)
    {
        isRunning = false;
    }
    SDL_Event event;
    int x, y;
    SDL_GetMouseState( &x, &y );
    bool splashScreen = true;
    bool mainMenu = false;
    bool game = false;
    main_menu mm(&mainTexture, &buttonTexture, &fontTexture);
    Map gameMap(&tileTexture, &platformTexture);
    splash_screen ss(&splashTexture);
    while (isRunning != false)
    {
        while (SDL_PollEvent(&event) != 0)
        {
            if (event.type == SDL_QUIT)
            {
                isRunning = false;
            }
            else if(event.type == SDL_MOUSEMOTION)
            {
                x = event.motion.x;
                y = event.motion.y;
                if (mainMenu)
                {
                    mm.mouseMotionEvents(x, y);
                }
            }
            else if (event.type == SDL_MOUSEBUTTONDOWN)
            {
                bool click = false;
                if (splashScreen)
                {
                    SDL_Delay(10);
                    mainMenu = true;
                    splashScreen = false;
                    break;
                }
                if (mainMenu)
                {
                    click = mm.mouseClickEvents(x, y);

                    if (click)
                    {
                        game = true;
                        mainMenu = false;
                        break;
                    }
                }
                if (game)
                {

                }
            }
        }
        SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);
        SDL_RenderClear(gRenderer);
        if (splashScreen)
        {
            ss.render(gRenderer);
        }
        else if (mainMenu)
        {
            mm.render(gRenderer);
        }
        else if (game)
        {
            gameMap.render(gRenderer);
        }
        SDL_RenderPresent(gRenderer);

    }
    clean();
    return 0;
}

bool init(string title, int x, int y, int width, int height, bool fullscreen) //Initialize SDL
{
    int flags = 0;
    bool isRunning;
    if (fullscreen)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        isRunning = false;
    }
    else
    {
        cout << "SDL Initialized! " << endl;
        window = SDL_CreateWindow(title.c_str(), x, y, width, height, flags);
        if (window)
        {
            cout << "Window created!" << endl;
        }
        gRenderer = SDL_CreateRenderer(window, -1, 0);
        if (gRenderer)
        {
            SDL_SetRenderDrawColor(gRenderer, 255, 255, 255, 255);
            cout << "Renderer created!" << endl;
        }
        isRunning = true;
    }
    cout << isRunning << endl;
    return isRunning;
}

bool loadMedia()
{
    bool success = true;
	if( !fontTexture.loadFromFile( "final small font.png", gRenderer ))
	{
		printf( "Failed to load font texture!\n" );
		success = false;
	}
    if (!mainTexture.loadFromFile("background.png", gRenderer))
    {
        printf( "Failed to load background texture!\n" );
		success = false;
    }
    if (!buttonTexture.loadFromFile("final final buttons.png", gRenderer))
    {
        printf( "Failed to load button texture!\n" );
		success = false;
    }
    if (!tileTexture.loadFromFile("Tile.png", gRenderer))
    {
        printf( "Failed to load tile texture!\n" );
		success = false;
    }
    if (!platformTexture.loadFromFile("platform tile.png", gRenderer))
    {
        printf( "Failed to load platform texture!\n" );
		success = false;
    }
    if (!splashTexture.loadFromFile("Splash.png", gRenderer))
    {
        printf( "Failed to load splash texture!\n" );
		success = false;
    }
	return success;

}

void render(SDL_Renderer* gRenderer)
{
    SDL_RenderClear(gRenderer);
    SDL_RenderPresent(gRenderer);
}

void clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(gRenderer);
    SDL_Quit();
    cout  << "Game cleaned!" << endl;
}
