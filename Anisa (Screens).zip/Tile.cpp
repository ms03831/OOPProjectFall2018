#include "Tile.h"

Tile::Tile()
{

}

Tile::Tile(LTexture* texture)
{
    this -> TileTex = texture;
    tileRect.x = 0;
    tileRect.y = 0;
    tileRect.w = 25;
    tileRect.h = 25;
}

Tile::~Tile()
{

}

void Tile::setPosition(int x, int y)
{

}

void Tile::render(SDL_Renderer* gRenderer)
{
    int i = 0, j = 150;
    while (j < 600)
    {
        i = 0;
        while (i < 800)
        {
            TileTex -> render(i, j, gRenderer, &tileRect);
            i += 25;
        }
        j += 175;
    }
}
