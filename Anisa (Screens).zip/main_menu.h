#ifndef MAIN_MENU_H_INCLUDED
#define MAIN_MENU_H_INCLUDED
#pragma once
#include "Screen.h"


class main_menu : public Screen
{

public:
    main_menu();
    main_menu(LTexture*, LTexture*, LTexture*);
    ~main_menu();
    void render(SDL_Renderer*);
    void setDimensions(int, int);

private:
    button* gameButton;
    LTexture* main_bg;
    LTexture* buttonTexture;
    int screen_width;
    int screen_height;
    SDL_Rect buttonRect[3];

};



#endif // MAIN_MENU_H_INCLUDED
