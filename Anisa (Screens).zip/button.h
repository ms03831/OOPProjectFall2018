#ifndef BUTTON_H_INCLUDED
#define BUTTON_H_INCLUDED
#pragma once
#include "word.h"

class button
{
public:
    button();
    button(LTexture*,LTexture*, int, int, std::string);
    ~button();
    void setPosition(int, int);
    void setText(std::string);
    void render(SDL_Renderer*);
    void changeState(std::string  state);
    //SDL_Rect* getPositions();

private:
    int x, y;
    int buttonState = 0;
    LTexture* btn;
    LTexture* fontTexture;
    word* buttonWord;
    SDL_Rect buttonRect[3];
    SDL_Rect* positions;



};



#endif // BUTTON_H_INCLUDED
