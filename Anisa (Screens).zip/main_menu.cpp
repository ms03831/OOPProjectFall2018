#include "main_menu.h"

main_menu::main_menu()
{

}

main_menu::main_menu(LTexture* tex, LTexture* buttonTex, LTexture* fontTex)
{
    std::string buttonText[4] = {"New Game", "Load Game", "Settings", "Exit"};
    main_bg = tex;
    screen_button = new button[4];
    int j = 0;
    for (int i = 0; i < 4; i++)
    {
        screen_button[i] = button(buttonTex, fontTex, 240, 200 + j, buttonText[i]);
        j+= 100;
    }
}

main_menu::~main_menu()
{

}

void main_menu::render(SDL_Renderer* gRenderer)
{
    main_bg -> render(0, 0, gRenderer);
    for (int i = 0; i < 4; i++)
    {
        screen_button[i].render(gRenderer);
    }
}

void main_menu::setDimensions(int, int)
{

}

