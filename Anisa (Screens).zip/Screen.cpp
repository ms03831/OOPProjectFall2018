#include "Screen.h"

Screen::Screen()
{

}

Screen::~Screen()
{

}

//Screen::Screen(LTexture*, LTexture*)
//{

//}
Screen::Screen(LTexture* sheetTexture)
{
    this -> bg = sheetTexture;
}

LTexture* Screen::getTexture()
{
    return bg;
}

void Screen::mouseMotionEvents(int x, int y)
{
    int temp = 100;
        for (int i = 0; i < 4; i++)
    {
        if (x >= 240 && x <= 552 && y >= 100 + temp && y <= 174 + temp)
        {
            screen_button[i].changeState("Hover");
        }
        else
        {
            screen_button[i].changeState("Default");
        }
        temp += 100;
    }
    /*for (int i = 0; i < 4; i++)
    {
        if (x >= screen_button[i].getPositions() -> x && x <= (screen_button[i].getPositions() -> x + screen_button[i].getPositions() -> w) && y >= 100 + temp && y <= 174 + temp)
        {
            screen_button[i].changeState("Hover");
        }
        else
        {
            screen_button[i].changeState("Default");
        }
        temp += 100;
    }*/
}

bool Screen::mouseClickEvents(int x, int y)
{
    bool clicked = false;
    int temp = 100;
    for (int i = 0; i < 4; i++)
    {
        if (x >= 240 && x <= 552 && y >= 100 + temp && y <= 174 + temp)
        {
            screen_button[i].changeState("Clicked");
            clicked = true;
            return clicked;
        }

        else
        {
            screen_button[i].changeState("Default");
        }
        temp += 100;
    }
}
