#ifndef SCREEN_H_INCLUDED
#define SCREEN_H_INCLUDED
#pragma once
#include "LTexture.h"
#include "button.h"

class Screen
{
public:
    Screen();
    ~Screen();
    //Screen(LTexture*, LTexture*);
    Screen(LTexture*);
    virtual void render(SDL_Renderer*) = 0;
    LTexture* getTexture();
    void mouseMotionEvents(int, int);
    bool mouseClickEvents(int, int);
    button* screen_button;

private:
    std::string img;
    std::string button_img;
    SDL_Texture* texture;

    LTexture* bg;

};



#endif // SCREEN_H_INCLUDED
