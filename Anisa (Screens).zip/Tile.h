#ifndef TILE_H_INCLUDED
#define TILE_H_INCLUDED
#pragma once
#include "LTexture.h"

class Tile
{
public:
    Tile();
    Tile(LTexture*);
    ~Tile();
    void setPosition(int, int);
    void render(SDL_Renderer*);

private:
    int x, y;
    LTexture* TileTex;
    SDL_Rect tileRect;
};

#endif // TILE_H_INCLUDED
