#include "splash_screen.h"
splash_screen::splash_screen()
{

}

splash_screen::splash_screen(LTexture* texture)
{
    splash_bg = texture;
}

splash_screen::~splash_screen()
{

}

void splash_screen::render(SDL_Renderer* gRenderer)
{
    splash_bg -> render(0, 0, gRenderer);
}
