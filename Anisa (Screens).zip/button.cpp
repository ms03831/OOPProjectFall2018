#include "button.h"

button::button()
{
    buttonWord = NULL;
    //buttonState = 0;
    positions = NULL;
    x = 0;
    y = 0;
}

button::button(LTexture* texture, LTexture* tex, int x, int y, std::string text)
{
    this -> buttonWord = new word(text, tex, x, y);
    this -> btn = texture;
    setPosition(x, y);

    buttonRect[0].x = 0;
    buttonRect[0].y = 0;
    buttonRect[0].w = 312;
    buttonRect[0].h = 74;

    buttonRect[1].x = 0;
    buttonRect[1].y = 100;
    buttonRect[1].w = 312;
    buttonRect[1].h = 74;

    buttonRect[2].x = 0;
    buttonRect[2].y = 200;
    buttonRect[2].w = 312;
    buttonRect[2].h = 74;


}

void button::setPosition(int x, int y)
{
    this -> x = x;
    this -> y = y;
}

void button::setText(std::string myString)
{
    buttonWord -> setText(myString);
    //setPosition(x, y);
}

void button::changeState(std::string state)
{
    if (state == "Hover")
    {
        buttonState = 1;
    }
    else if (state == "Default")
    {
        buttonState = 0;
    }
    else if (state == "Clicked")
    {
        buttonState = 2;
    }
}

void button::render(SDL_Renderer* gRenderer)
{
    btn -> render(this -> x, this -> y, gRenderer, &buttonRect[buttonState]);
    buttonWord -> render(gRenderer);
}

/*SDL_Rect* button::getPositions()
{
    //std::cout  << "jello" << std::endl;
    std::cout  << "my x: " << this -> x << std::endl;
    //std::cout << positions -> x << std::endl;
    positions -> x = x;
    //positions->x = this -> x;
    positions->y = this -> y;
    //positions->w = buttonRect[buttonState].w;
    //positions->h = buttonRect[buttonState].h;

    return positions;
}*/



button::~button()
{

}
