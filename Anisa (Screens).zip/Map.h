#ifndef MAP_H_INCLUDED
#define MAP_H_INCLUDED
#include "LTexture.h"
#include "Tile.h"

class Map
{
public:
    Map();
    Map(LTexture*, LTexture*);
    ~Map();
    void setObjects();
    //void load();
    void render(SDL_Renderer*);

private:
    //Position entryPoint;
    //Position exitPoint;
    LTexture* gameMap;
    LTexture* platformTexture;
    Tile* platform;
    SDL_Rect gTileClip;
};

#endif // MAP_H_INCLUDED
