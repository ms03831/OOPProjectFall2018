#ifndef CHARACTER_H_INCLUDED
#define CHARACTER_H_INCLUDED
#pragma once
#include "LTexture.h"

class character
{

public:
    character();
    character(char, LTexture*);
    ~character();
    void render(SDL_Renderer*);
    void setPosition(int, int);
    void setTexture(LTexture*, char, int, int, int);
    void setChar(char);


private:
    int x, y;
    SDL_Rect charRect;
    char showChar;
    LTexture* charTexture;
    bool prev = false;
};


#endif // CHARACTER_H_INCLUDED
