#include "character.h"

character::character()
{

    x = 0;
    y = 0;
}

character::character(char chr, LTexture* spriteTexture)
{

}

void character::render(SDL_Renderer* gRenderer)
{
    charTexture -> render((this-> x)*0.7, this -> y, gRenderer, &charRect);
}

void character::setPosition(int x, int y)
{
    this -> x = x;
    this -> y = y;
}

void character::setTexture(LTexture* sheetTexture, char chr, int i, int x, int y)
{
    this -> showChar = chr;
    this -> charTexture = sheetTexture;
    this -> charRect.w = 62;
    this -> charRect.h = 67;
    this -> setPosition((x+140) + i, y);
    this -> setChar(chr);
}



void character::setChar(char chr)
{
    int asciiCode = int(chr);
    int posX = 0, posY = 0;
    if (asciiCode == 32)
    {
        this -> charRect.x = 660;
        this -> charRect.y = 180;
    }
    for (int i = 65; i < 122; i++)
    {
        if (i == 74 || i == 83 || i == 97 || i == 106 || i == 115)
        {
            posX = 0;
        }
        if (asciiCode == i && asciiCode <= 73)
        {
            this -> charRect.x = posX;
            this -> charRect.y = posY;
            break;
        }
        if (asciiCode == i && asciiCode > 73 && asciiCode <= 82 )
        {
            this -> charRect.x = posX;
            this -> charRect.y = 67;
            break;
        }
        if (asciiCode == i && asciiCode > 82 && asciiCode <= 90)
        {
            this -> charRect.x = posX;
            this -> charRect.y = 135;
            break;
        }
        if (asciiCode == i && asciiCode > 96 && asciiCode <= 105)
        {
            this -> charRect.x = posX;
            this -> charRect.y = 216;
            break;
        }
        if (asciiCode == i && asciiCode > 105 && asciiCode <= 114)
        {
            this -> charRect.x = posX;
            this -> charRect.y = 283;
            break;
        }
        if (asciiCode == i && asciiCode > 114 && asciiCode <= 122)
        {
            this -> charRect.x = posX;
            this -> charRect.y = 351;
            break;
        }
        posX += 62;
    }
}

character::~character()
{

}

