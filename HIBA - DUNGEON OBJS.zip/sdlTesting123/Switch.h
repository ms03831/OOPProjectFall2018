#pragma once
#include "DungeonObject.h"

class Switch: public DungeonObject
{
public:
    Switch(){}
    Switch(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){
                                                           display = true;
                                                       }

     virtual ~Switch(){}

    /** Inherited pure virtual functions form abstract base class */
    void Interaction();
};
