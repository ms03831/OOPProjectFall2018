#include "Rack.h"

void Rack::Interaction()
{
    //
}
