#pragma once
#include "DungeonObject.h"

class RedSwitch: public DungeonObject
{
public:
    RedSwitch(){}
    RedSwitch(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){
                                                           display = true;
                                                       }

    virtual ~RedSwitch(){}

    void update();
    void render();

    /** Inherited pure virtual functions form abstract base class */
    void Interaction();
};
