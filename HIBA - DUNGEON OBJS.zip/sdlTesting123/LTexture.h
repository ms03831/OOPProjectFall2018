#pragma once
#include "Game.h"

class LTexture
{
private:
    SDL_Texture* texture;
    int width;
    int height;
public:
    /** Default constructor */
    LTexture();
    /** Default destructor */
    virtual ~LTexture();

    bool loadFromFile(const char*, SDL_Renderer*);
    void free();        // deallocate/delete memory
    void render(int, int, SDL_Rect*);

    /** Getters/Setters */
    int getWidth();
    int getHeight();
};
