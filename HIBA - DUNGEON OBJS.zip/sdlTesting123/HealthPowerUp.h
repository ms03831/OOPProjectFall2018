#pragma once
#include "DungeonObject.h"

class HealthPowerUp: public DungeonObject
{
public:
    HealthPowerUp(){}
    /** Overloaded constructor */
    HealthPowerUp(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){
                                                           display = true;
                                                       }
    /** Default destructor */
    virtual ~HealthPowerUp();

    /** Inherited pure virtual functions form abstract base class */
    void Interaction();
};
