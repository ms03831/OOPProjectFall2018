#include "RedSwitch.h"
#include "Door.h"

void RedSwitch::Interaction()
{
    CONTROLLED_OBJECT->setAnimate(true);
}

void RedSwitch::update()
{
    if (CONTROLLED_OBJECT != nullptr)
        CONTROLLED_OBJECT->update();
}

void RedSwitch::render()
{
    SDL_Rect src = getSourceRect();
    SDL_Rect dst = getDestRect();
    SDL_RenderCopy(getRenderer(), getTexture(), &src, &dst);
   // if (CONTROLLED_OBJECT != nullptr)
   //     SDL_RenderCopy(getRenderer(), getTexture(), &src, &dst);
    Uint32 f = getFrameRate();
    f++;
    setFrameRate(f);
}
