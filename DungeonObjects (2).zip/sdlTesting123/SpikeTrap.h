#pragma once
#include "Traps.h"

class SpikeTrap: public Traps
{
public:
    SpikeTrap(){}
    SpikeTrap(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Traps(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight)
                                                       {
                                                           spritesNumber = 4;
                                                           sprites = new int[spritesNumber];

                                                           sprites[0] = 0;
                                                           sprites[1] = 191;
                                                           sprites[2] = 382;
                                                           sprites[3] = 573;
                                                       }
    virtual ~SpikeTrap(){}

    void render();
    void update();
    /** Inherited pure virtual functions form abstract base class */
    void Interaction();
};
