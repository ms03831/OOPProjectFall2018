#pragma once
#include "Weapons.h"

class Arrow: public Weapons
{
public:
    Arrow(){}
    Arrow(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Weapons(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){

                                                           display = true;
                                                           direction = true;
                                                       }
    virtual ~Arrow(){}

    void render();
    void update();

    void Interaction();
};
