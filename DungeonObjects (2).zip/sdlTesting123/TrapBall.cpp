#include "TrapBall.h"

void TrapBall::Interaction()
{
    //
}

void TrapBall::update()
{
    if (getFrameRate() > 1900)
    {
        if (getFrameRate() <2400)
        {
            Position p;
            p = getPosition();
            p.y--;
            if (p.y >0)
                setPosition(p);
        }
        if (getFrameRate() > 2400 && getFrameRate() < 2600 )
        {
            Position p;
            p = getPosition();
            p.y++;
            setPosition(p);
        }
        if (getFrameRate() > 2600 && getFrameRate() <2700)
        {
            if (getFrameRate() % 3 == 0)
            {
                Position p;
                p = getPosition();
                p.x++;
                p.y--;
                setPosition(p);
            }
        }
        if (getFrameRate() > 2900 && getFrameRate() < 3000)
        {
            if (getFrameRate() % 3 == 0)
            {
                Position p;
                p = getPosition();
                p.x++;
                p.y++;
                setPosition(p);
            }
        }

    }
}
