#include "Arrow.h"

void Arrow::Interaction()
{
    //
}

void Arrow::render()
{
    const SDL_Rect source = getSourceRect();
    const SDL_Rect dest = getDestRect();

    SDL_Point p;
    p.x = dest.x/2;
    p.y = dest.y/2;

    if (!direction)
        SDL_RenderCopyEx(getRenderer(), getTexture(), &source, &dest, 218, &p, SDL_FLIP_HORIZONTAL);
    else
        SDL_RenderCopyEx(getRenderer(), getTexture(), &source, &dest, 38, &p, SDL_FLIP_HORIZONTAL);
}

void Arrow::update()
{

}


