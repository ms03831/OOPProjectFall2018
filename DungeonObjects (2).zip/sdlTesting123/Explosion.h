#pragma once
#include "Torch.h"

class Explosion: public Torch
{
public:
    Explosion(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Torch(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){}
    virtual ~Explosion(){}

    void update();

    void Interaction();
};
