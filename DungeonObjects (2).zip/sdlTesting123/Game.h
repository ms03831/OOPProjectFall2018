#pragma once
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "Position.h"
#include "TextureManager.h"
#include "DungeonObject.h"

class Game
{
private:
    bool isRunning;
    SDL_Window* window;
    SDL_Renderer* renderer;
public:
    Game(){}
    virtual ~Game(){}

    void init(const char*, Position pos, int width, int height, bool fullscreen);
    void handleEvents();
    virtual void update();
    void render();
    void clean();

    bool running()
    {
        return isRunning;
    }
};
