#pragma once

class Position
{
public:
    /** Default constructor */
    Position();
    /** Overloaded constructor */
    Position(int x, int y);
    /** Default destructor */
    ~Position();

    int x;  // x-axis position
    int y;  // y-axis position

    /** Static function to create and return a Position object in place */
    static Position Set(int x, int y);
};
