#include "Weapons.h"

void Weapons::Interaction()
{
    //
}
