#pragma once
#include "Torch.h"

class EnemyTrapExplosion: public Torch
{
public:
    EnemyTrapExplosion(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Torch(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){}
    virtual ~EnemyTrapExplosion(){}

    void update();

    void Interaction();
};
