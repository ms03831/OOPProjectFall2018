#pragma once
#include "DungeonObject.h"

class Haystack: public DungeonObject
{
public:
    Haystack(){}
    /** Overloaded constructor */
    Haystack(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight)
    {
        spritesNumber = 4;
        sprites = new int[spritesNumber];
        sprites[0] = 0;
        sprites[1] = 508;
        sprites[2] = 1013;
        sprites[3] = 1518;

        runTime = 1;
        display = true;
    }
    /** Default destructor */
    virtual ~Haystack(){}

    void update();
    /** Inherited pure virtual functions form abstract base class */
    void Interaction();
};

