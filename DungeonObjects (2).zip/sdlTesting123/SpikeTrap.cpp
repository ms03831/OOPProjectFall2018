#include "SpikeTrap.h"

void SpikeTrap::Interaction()
{
    //
}

void SpikeTrap::render()
{
    if (getFrameRate() % 100 == 0)
    {
        const SDL_Rect source = getSourceRect();
        const SDL_Rect dest = getDestRect();

        SDL_Point p;
        p.x = dest.x/6;
        p.y = dest.y/6;

        SDL_RenderCopyEx(getRenderer(), getTexture(), &source, &dest, runTime, &p, SDL_FLIP_HORIZONTAL);
    }
}

void SpikeTrap::update()
{
    runTime+=1;
    if (runTime == 1800)
    {
        display = false;
        animate = false;
    }
}
