#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include "Position.h"
#include "LoadGame.h"

using namespace std;

int main( int argc, char* args[] )
{
    srand(time(NULL));
    init("Pasbaan-e-Zafar", Position::Set(SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED), 1200, 600, false);

    while (running())
    {
        render();
        update();
        handleEvents();
    }

    clean();

    getch();
    return 0;
}
