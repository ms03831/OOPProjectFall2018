#pragma once
#include "Game.h"

class Drawers: public DungeonObject
{
public:
    /** Overloaded constructor */
    Drawers(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight)
    {
        spritesNumber = 3;
        sprites = new int[spritesNumber];

        sprites[0] = 0;
        sprites[1] = 762;
        sprites[2] = 1532;
    }
    /** Default destructor */
    virtual ~Drawers(){}

    void update();
    /** Inherited pure virtual functions form abstract base class */
    bool isCharacterInteracting(Position characterPos);
    void Interaction();
};
