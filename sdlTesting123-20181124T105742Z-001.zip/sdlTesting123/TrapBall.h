#pragma once
#include "Traps.h"

class TrapBall: public Traps
{
public:
    /** Overloaded constructor */
    TrapBall(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Traps(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight)
                                                       {}
    /** Default destructor */
    virtual ~TrapBall(){}

    void update();
    /** Inherited pure virtual functions form abstract base class */
    bool isCharacterInteracting(Position pos);
    void Interaction();
};
