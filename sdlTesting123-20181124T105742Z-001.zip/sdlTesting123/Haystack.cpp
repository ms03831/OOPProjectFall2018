#include "Haystack.h"

bool Haystack::isCharacterInteracting(Position pos)
{
    return true;
}

void Haystack::Interaction()
{
    //
}

int i = 1;

void Haystack::update()
{
    if (i==spritesNumber)
        i = 1;

    if (getFrameRate() % 140 == 0)
    {
        SDL_Rect r;
        r.h = 500;
        r.w = 648;
        r.x = 0;
        r.y = sprites[i];
        setSourceRect(r);
        std::cout << "\t\t" << getFrameRate() << "\n";
        i++;
    }
}
