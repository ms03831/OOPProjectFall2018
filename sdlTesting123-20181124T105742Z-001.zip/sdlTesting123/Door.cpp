#include "Door.h"

bool Door::isCharacterInteracting(Position pos)
{
    return true;
}

void Door::Interaction()
{
    //
}

void Door::update()
{
    if (getFrameRate() % 400 == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        int x = runTime;
        r.y = sprites[x];
        setSourceRect(r);
        runTime++;

        if (runTime == spritesNumber)
            animate = false;
    }
}
