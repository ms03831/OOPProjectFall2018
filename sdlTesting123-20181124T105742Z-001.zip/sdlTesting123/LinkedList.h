#pragma once
#include "Node.h"

template <typename T>
class LinkedList
{
private:
    Node<T>* head;
    Node<T>* tail;
public:
    /** Default constructor */
    LinkedList()
    {
        head = NULL;
        tail = NULL;
    }

    Node<T>* getHead()
    {
        return head;
    }
    Node<T>* getTail()
    {
        return tail;
    }
    void push(int index, T data)     //  push value of type T at specified index
    {
        if (index == 0)
        {
            head = new Node<T>;
            head->data = data;
            head->prev = NULL;
            head->next = NULL;
            head->index = index;

            tail = head;              // since no other node in linked list
        }
        else
        {
            Node<T>* temp = head;
            while (temp->index != index-1)      // node found right before target destination
            {
                temp = temp->next;
            }
            // the temp found can be in the middle of two existing nodes,
            // meaning: it can either be null or not null
            if (temp->next == NULL)             // case when target destination is empty
            {
                temp->next = new Node<T>;
                temp->next->data = data;
                temp->next->prev = temp;
                temp->next->next = NULL;
                temp->next->index = index;
                tail = temp->next;                    // since this is the last element now
            }
            else                                // case when target destination is already an existing node
            {
                Node<T>* tempNext = temp->next;
                Node<T>* dest = new Node<T>;
                temp->next = dest;
                tempNext->prev = dest;
                // now dest is linked with its previous and next Nodes
                // assigning attributes to dest itself
                dest->prev = temp;
                dest->next = tempNext;
                dest->index = index;
                dest->data = data;

                /**   All is well, but the upcoming indices now need to be changed as dest->next
                      has the same index as dest   */
                temp = tempNext;
                while (temp != NULL)        // runs till after tail
                {
                    index++;
                    temp->index = index;
                    tail = temp;
                    temp = temp->next;
                }
            }
        }
    }
    T pop(int index)            // pop and retrieve value of type T at specified index
    {
        T value;
        Node<T>* temp = head->next;
        if (index == 0)
        {
            value = head->data;
            delete head;
            head = temp;
            head->prev = NULL;
        }
        else
        {
            while (temp->index != index)
            {
                temp = temp->next;
            }
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
            value = temp->data;
            delete temp;
        }
        // now set back all the indices right
        temp = head;
        int i = 0;
        while (temp != NULL)
        {
            temp->index = i;
            tail = temp;
            temp = temp->next;
            i++;
        }
        return value;
    }
    int getSize();
    void show();            // show all objects stored in linked list
    T  getElement(int index)
    {
        Node<T>* temp = head;
        while (temp != NULL)
        {
            if (temp->index == index)
                return temp->data;
            temp = temp->next;
        }
        return NULL;
    }

    /** Default destructor */
    virtual ~LinkedList()
    {
        if (head != NULL)
        {
            Node<T>* temp = head;
            Node<T>* temp2;
            do
            {
                temp2 = temp->next;
                delete temp;
                temp = temp2;
            }
            while(temp != NULL);
            delete temp;
        }
    }
};
