#include "Weapons.h"

bool Weapons::isCharacterInteracting(Position pos)
{
    return true;
}

void Weapons::Interaction()
{
    //
}
