#include "Keys.h"

bool Keys::isCharacterInteracting(Position pos)
{
    return true;
}

void Keys::Interaction()
{
    //
}
