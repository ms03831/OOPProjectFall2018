#pragma once
#include "Weapons.h"

class Arrow: public Weapons
{
public:
    Arrow(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Weapons(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){}
    virtual ~Arrow(){}

    void render();
    void update();

    bool isCharacterInteracting(Position);
    void Interaction();
};
