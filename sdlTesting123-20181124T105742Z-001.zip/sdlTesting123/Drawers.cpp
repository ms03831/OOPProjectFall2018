#include "Drawers.h"

bool Drawers::isCharacterInteracting(Position)
{
    return true;
}

void Drawers::Interaction()
{
    //
}

int j = 1;

void Drawers::update()
{
    // movement
    if (getFrameRate() % 5 == 0)
    {
        Position p;
        p = getPosition();
        p.x++;
        setPosition(p);
    }

    // sprites
    if (j==spritesNumber)
        j = 1;

    if (getFrameRate() % 180 == 0)
    {
        SDL_Rect r;
        r.h = 627;
        r.w = 414;
        r.x = 0;
        r.y = sprites[j];
        setSourceRect(r);
        j++;
    }
}
