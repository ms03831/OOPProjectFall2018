#include "Torch.h"

bool Torch::isCharacterInteracting(Position pos)
{
    return true;
}

void Torch::Interaction()
{

}

int t = 0;

void Torch::update()
{
    if (getFrameRate() % 120 == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        r.y = sprites[t];
        setSourceRect(r);
        t++;
        if (t >= spritesNumber)
            t = 0;
    }
}
