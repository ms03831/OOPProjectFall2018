#include <iostream>
#include "DungeonObject.h"
#include "Door.h"
#include "Drawers.h"
#include "Haystack.h"
#include "HealthPowerUp.h"
#include "Keys.h"
#include "Torch.h"
#include "Traps.h"
#include "Weapons.h"
#include "FallingTrap.h"
#include "SpikeTrap.h"
#include "TrapBall.h"
#include "EnemyTrapExplosion.h"
#include "LinkedList.h"
#include "Node.h"
#include "Arrow.h"

using namespace std;

DungeonObject* obj;
DungeonObject* key;
DungeonObject* hayy;
DungeonObject* ftrap;
DungeonObject* door;
DungeonObject* torch;
DungeonObject* spikey;
DungeonObject* ball;
DungeonObject* explosion;
DungeonObject* arrow;

bool isRunning;
SDL_Window* window;
SDL_Renderer* renderer;

LinkedList<DungeonObject*> l;

void init(const char* title, Position pos, int width, int height, bool fullscreen)
{
    int flags = 0;
    if (fullscreen)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }

    if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
    {
        cout << "SDL INITIALIZED." << endl;
        window = SDL_CreateWindow(title, pos.x, pos.y, width, height, flags);
        if (window)
        {
            cout << "Window created." << endl;
        }

        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 5);
            cout << "Renderer created." << endl;
        }
        isRunning = true;
    }
    else
    {
        isRunning = false;
    }
    obj = new Drawers("drawersp.png", renderer, Position::Set(0,0), 414, 626, Position::Set(0, 0), 80, 180);
    l.push(0, obj);

    key = new Keys("KEY.png", renderer, Position::Set(0, 0), 2000, 695, Position::Set(350, 0), 100, 30);
    l.push(1, key);

    hayy = new Haystack("haystacksp.png", renderer, Position::Set(0, 0), 648, 508, Position::Set(0, 50), 100, 200);
    l.push(0, hayy);

    ftrap = new FallingTrap("fallingtrapsp.png", renderer, Position::Set(0, 0), 134, 88, Position::Set(0, 50), 100, 50);
    l.push(1, ftrap);

    door = new Door("door.png", renderer, Position::Set(0, 0), 59, 62, Position::Set(100, 50), 60, 65);
    l.push(2, door);

    torch = new Torch("torchsp.png", renderer, Position::Set(0, 0), 250, 701, Position::Set(100, 100), 30, 80);
    l.push(3, torch);

    spikey = new SpikeTrap("spikeyy.png", renderer, Position::Set(0, 0), 181, 177, Position(100, 50), 80, 80);
    l.push(4, spikey);

    ball = new TrapBall("dungeonball.png", renderer, Position::Set(0,0), 173, 167, Position(300, 300), 90, 90);
    l.push(5, ball);

    explosion = new EnemyTrapExplosion("explosion.png", renderer, Position::Set(0, 0), 79, 79, Position(80, 40), 180, 180);
    l.push(6, explosion);

    arrow = new Arrow("arrow.png", renderer, Position::Set(0, 0), 300, 275, Position(100, 50), 100, 80);
    l.push(7, arrow);
}




bool running()
{
    return isRunning;
}

void handleEvents()
{
    SDL_Event event;
    SDL_PollEvent(&event);

    switch (event.type)
    {
    case SDL_QUIT:
        isRunning = false;
        break;
    case SDL_KEYUP:
        spikey->setDisplay(true);
        spikey->setAnimate(true);
        spikey->setRunTime(0);
        cout <<"detected a\n";
        break;
    case SDL_KEYDOWN:
        door->setAnimate(true);
        door->setRunTime(0);
        break;
    default:
        break;
    }
}


void render()
{
    SDL_RenderClear(renderer);

    DungeonObject* o;

    for (int i = 0; i <= 7; i++)
    {
        o = l.getElement(i);
        //if (o->getDisplay())
            o->render();
    }



    SDL_RenderPresent(renderer);
}

bool checkCollision(SDL_Rect firstObj, SDL_Rect secondObj)
{
    //The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    //Calculate the sides of rect firstObj
    leftA = firstObj.x;
    rightA = firstObj.x + firstObj.w;
    topA = firstObj.y;
    bottomA = firstObj.y + firstObj.h;

    //Calculate the sides of rect secondObj
    leftB = secondObj.x;
    rightB = secondObj.x + secondObj.w;
    topB = secondObj.y;
    bottomB = secondObj.y + secondObj.h;

    //If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        return false;
    }

    if( topA >= bottomB )
    {
        return false;
    }

    if( rightA <= leftB )
    {
        return false;
    }

    if( leftA >= rightB )
    {
        return false;
    }

    //If none of the sides from firstObj are outside secondObj
    return true;
}

void update()
{
    if (spikey->getAnimate())
        spikey->update();
    obj->update();
    ftrap->update();
    if (door->getAnimate())
        door->update();
    torch->update();

    ball->update();
    explosion->update();
}

void clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    cout << "All memory deallocated" << endl;
}

