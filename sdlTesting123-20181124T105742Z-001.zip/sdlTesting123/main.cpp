#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include <iostream>
#include "LinkedList.h"
#include <conio.h>
#include "Position.h"
#include "DungeonObject.h"
#include "Torch.h"

using namespace std;

void init(const char* title, Position pos, int width, int height, bool fullscreen);
void handleEvents();
void render();
void clean();
void update();
bool running();

int main( int argc, char* args[] )
{
    init("New Game", Position::Set(SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED), 640, 480, false);

    while (running())
    {
        handleEvents();
        update();
        render();
    }

    clean();

    /*
    LinkedList<int> l;
    l.push(0, 1);
    l.push(1, 2);
    l.push(2, 3);
    Node<int>* head = l.getHead();
    while (head != NULL)
    {
        cout << head->data << endl;
        head = head->next;
    }*/

    getch();
    return 0;
}
