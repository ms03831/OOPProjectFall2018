#include "EnemyTrapExplosion.h"

bool EnemyTrapExplosion::isCharacterInteracting(Position)
{
    return false;
}

void EnemyTrapExplosion::Interaction()
{
    //
}

int e = 0;

void EnemyTrapExplosion::update()
{
    if ( getFrameRate() % 25 == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        if (e < 8)
        {
            r.x+=r.w;
            setSourceRect(r);
        }
        else
        {
            if (r.y < 474)
            {
                r.y+=r.h;
                r.x = 0;
                setSourceRect(r);
            }
            else
            {
                r.y = 0;
                setSourceRect(r);
            }
            e = 0;
        }
        e++;
    }
}
