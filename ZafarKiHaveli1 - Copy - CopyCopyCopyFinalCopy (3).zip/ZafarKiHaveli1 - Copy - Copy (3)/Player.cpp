#include "Game.h"
#include "Player.h"
#include "MovingObject.h"
#include "Health.h"
#include "TextureManager.h"

Player::Player(LTexture* textureSheet, int x, int y, int R, int G, int B):MovingObject(textureSheet, x, y, R, G, B)
{
    this->idle = true;
    this->walkingRect = new SDL_Rect[9];
    this->attackingRect = new SDL_Rect[2];
    //WALKING ANIMATION
    this->walkingRect[0].x = 0;
    this->walkingRect[0].y = 708;

    for (int i = 0; i < 9; i++)
    {
        this->walkingRect[i].w = 64;
        this->walkingRect[i].h = 64;
        this->walkingRect[i].x = this->walkingRect[0].x + i*this->walkingRect[0].w;
        this->walkingRect[i].y = this->walkingRect[0].y;
    }
    //ATTACK ANIMATION
    this->attackingRect[0].x = 64*3;
    this->attackingRect[0].y = 964;

    for (int i = 0; i < 2; i++)
    {
        this->attackingRect[i].w = 64;
        this->attackingRect[i].h = 64;
        this->attackingRect[i].x = this->attackingRect[0].x + 2*i*this->attackingRect[0].w;
        this->attackingRect[i].y = this->attackingRect[0].y;
    }

    this->renderRect = new SDL_Rect[this->divFrames];

    for (int i = 0; i < this->divFrames; i++)
        this->renderRect[i] = this->walkingRect[i];

    this->destRect.w = this->renderRect[0].w*2.3;
    this->destRect.h = this->renderRect[0].h*2.3;
    this->destRect.y = this->GetY() - this->destRect.h + 15;
    this->destRect.x = this->GetX();
}

void Player::Render()
{
    //frames++;
    if (Game::frames % 5 == 0)
    {
        ChangeSpriteIndex(this->divFrames);
    }
    if (this->GetAlive() && !this->IsHiding())
    {
        if ( idle )
        {
            this->GetOTexture()->Render(&this->walkingRect[ 0 ], &this->destRect, 0.0, nullptr, flip, Game::renderer);
        }
        else
        {
            this->GetOTexture()->Render(&this->renderRect[ this->GetSpriteIndex() ], &this->destRect, 0.0, nullptr, flip, Game::renderer);
        }
        this->RenderHealth();
    }
}


void Player::Move(int n)
{
    if (this->GetAlive() && !this->IsHiding())
    {
        if (this->GetX() < 0)
        this->SetX(0);

        else if (this->GetX() > 1100)
            this->SetX(1100);

        if (n == 0) //right
        {
            this->idle = false;
            cout << "RIGHT MOVINGGGGGG" << this->GetX() << endl;
            this->flip = SDL_FLIP_NONE;
            this->SetX(this->GetX() + 2);
            if ( this->GetX() > 1100 )
                this->SetX(1100);
        }

        else if (n == 1) //left
        {
            this->idle = false;
            this->flip = SDL_FLIP_HORIZONTAL;
            this->SetX(this->GetX() - 2);
            if ( this->GetX() < 0 )
                this->SetX(0);
        }

        if (n == -1) //right with camera
        {
            this->idle = false;
            cout << "RIGHT MOVINGGGGGG" << this->GetX() << endl;
            this->flip = SDL_FLIP_NONE;
            this->SetX(this->GetX() + 1);
            if ( this->GetX() > 1100 )
                this->SetX(1100);
        }

        else if (n == -2) //left with camera
        {
            this->idle = false;
            this->flip = SDL_FLIP_HORIZONTAL;
            this->SetX(this->GetX() - 1);
            if ( this->GetX() < 0 )
                this->SetX(0);
        }

        else if (n == 2) //attack
        {
            idle = false;
            this->divFrames = 2;
            delete[] this->renderRect;
            this->renderRect = new SDL_Rect[divFrames];

            for (int i = 0; i < this->divFrames; i++)
                this->renderRect[i] = this->attackingRect[i];
        }

        else if ( n == 3 ) //idle
        {
            this->idle = true;
            this->divFrames = 9;
            delete[] this->renderRect;
            this->renderRect = new SDL_Rect[divFrames];

            for (int i = 0; i < this->divFrames; i++)
                this->renderRect[i] = this->walkingRect[i];
        }

        else if ( n == 10 )
        {
            this->idle = false;
            this->flip = SDL_FLIP_HORIZONTAL;
            this->SetX(this->GetX() - 50);
            this->ChangeFloor();
        }

        this->destRect.x = this->GetX();
        this->destRect.y = this->GetY() + 15 - this->destRect.h;
    }
}

void Player::ChangeFloor()
{
    this->SetY(this->GetY() - 400);
}

//void Player::ChangeWeapon(int type)
//{
//    switch(type)
//    {
//    case 1:
//        //WALKING ANIMATION
//        this->walkingRect[0].x = 0;
//        this->walkingRect[0].y = 708;
//
//        for (int i = 0; i < 9; i++)
//        {
//            this->walkingRect[i].w = 64;
//            this->walkingRect[i].h = 64;
//            this->walkingRect[i].x = this->walkingRect[0].x + i*this->walkingRect[0].w;
//            this->walkingRect[i].y = this->walkingRect[0].y;
//        }
//        //ATTACK ANIMATION
//        this->attackingRect[0].x = 64*3;
//        this->attackingRect[0].y = 964;
//
//        for (int i = 0; i < 2; i++)
//        {
//            this->attackingRect[i].w = 64;
//            this->attackingRect[i].h = 64;
//            this->attackingRect[i].x = this->attackingRect[0].x + 2*i*this->attackingRect[0].w;
//            this->attackingRect[i].y = this->attackingRect[0].y;
//        }
//        break;
//    case 2:
//        //spear
//        break;
//
//    default:
//        break;
//    }
//}

Player::~Player()
{
    //delete renderRect;
}
