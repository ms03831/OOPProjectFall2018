#include "MovingObject.h"
#include "TextureManager.h"
#include "Game.h"

MovingObject::MovingObject(LTexture* textureSheet, int x, int y, int R, int G, int B)
{
    this->oTexture = textureSheet;
    this->healthtex = TextureManager::LoadTexture( "health.png", Game::renderer );
    this->SetDirection(1);
    this->SetVelocity(1);
    this->SetX(x);
    this->SetY(y);
    this->SetHealth(20);
    this->SetAlive(true);
    this->spriteIndex = 0;
}

MovingObject::MovingObject()
{

}

MovingObject::~MovingObject()
{
    renderRect = nullptr;
    delete renderRect;
    walkingRect = nullptr;
    delete renderRect;
    attackingRect = nullptr;
    delete renderRect;
}

void MovingObject::ReduceHealth(int type)
{
    if (health == 0)
    {
        this->alive = false;
    }
    else
    {
        switch( type )
        {
        case 0: //traps
            this->health--;
            break;
        case 1: //Chota enemy
            this->health -= 1;
            break;
        case 2: //Medium Enemy
            this->health -= 3;
            break;
        case 3: //bara enemy
            this->health -= 6;
            break;
        default:
            break;
        }
    }
}

int MovingObject::GetFloor()
{
    if ( this->GetY() > 0 && this->GetY() < 600 )
    {
        return 1;
    }

    else if ( this->GetY() > 600 && this->GetY() < 1200 )
    {
        return 2;
    }

    else if ( this->GetY() > 1200 && this->GetY() < 1800 )
    {
        return 3;
    }
}

void MovingObject::ChangeSpriteIndex(int divFrames)
{
    if (spriteIndex < divFrames - 1)
    {
        spriteIndex++;
    }

    else
    {
        spriteIndex = 0;
    }
}

void MovingObject::RenderHealth()
{
    for (int i = 0; i < this->GetHealth(); i++)
    {
        SDL_Rect hDst = {this->destRect.x + destRect.w/4, this->destRect.y - destRect.h/14, this->GetHealth()*4, 10};
        SDL_RenderCopy(Game::renderer, this->healthtex, nullptr, &hDst);
    }
}
