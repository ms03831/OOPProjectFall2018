#include "Zafar.h"

Zafar::Zafar()
{
    //ctor
}

Zafar::Zafar(LTexture* textureSheet, int x, int y, int R, int G, int B)
{
//    this->idle = true;
//    this->walkingRect = new SDL_Rect[9];
//    this->attackingRect = new SDL_Rect[2];
//    //WALKING ANIMATION
//    this->walkingRect[0].x = 0;
//    this->walkingRect[0].y = 708;
//
//    for (int i = 0; i < 9; i++)
//    {
//        this->walkingRect[i].w = 64;
//        this->walkingRect[i].h = 64;
//        this->walkingRect[i].x = this->walkingRect[0].x + i*this->walkingRect[0].w;
//        this->walkingRect[i].y = this->walkingRect[0].y;
//    }
//
//    this->renderRect = new SDL_Rect[this->divFrames];
//
//    for (int i = 0; i < this->divFrames; i++)
//        this->renderRect[i] = this->walkingRect[i];
//
//    this->destRect.w = this->renderRect[0].w*2.3;
//    this->destRect.h = this->renderRect[0].h*2.3;
//    this->destRect.y = this->GetY() - this->destRect.h + 15;
//    this->destRect.x = this->GetX();
//    zafarTex = textureSheet;
    this->SetX(x);
    this->SetY(y);
    safe = false;
    idleRect.x = idleRect.y = 0;
    idleRect.w = 33;
    idleRect.h = 50;

    //WALKING ANIMATION

    walkingRect[0].x = 0;
    walkingRect[0].y = 50;

    for (int i = 0; i < 4; i++)
    {
        walkingRect[i].w = 33;
        walkingRect[i].h = 50;
        walkingRect[i].x = walkingRect[0].x + i*walkingRect[0].w;
        walkingRect[i].y = walkingRect[0].y;
    }
    renderRect = new SDL_Rect[1];
    for (int i = 0; i < 1; i++) renderRect[i] = idleRect;
    destRect.x = this->GetX();
    destRect.y = this->GetY();
    destRect.w = renderRect[0].w*3;
    destRect.h = renderRect[0].h*3;
}

Zafar::~Zafar()
{
    delete renderRect;
    delete zafarTex;
}
