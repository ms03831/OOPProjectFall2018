#include "EnemyFactory.h"


ObjectFactory::ObjectFactory()
{
    chotuSpriteSheet.LoadFromFile( "chotaenemy1.png", Game::renderer );
    mediumSpriteSheet.LoadFromFile( "mediumenemy1.png", Game::renderer );
    baruSpriteSheet.LoadFromFile( "baraenemy1.png", Game::renderer );
    for (int i = 1; i < 4; i++)
        GenerateEnemiesFloor(i);
}

//ObjectFactory(somedatatype load); //overloaded for positions of the previous game

void ObjectFactory::GenerateEnemiesFloor(int floor)
{
    int x(0), y(0);
    // choice = 1 for chotu, 2 for medium, 3 for baru
    switch ( floor )
    {
    case 1:

        y = 200;

        for (int n = 0; n < 5; n++)
        {
            if ( n % 2 == 0 )
            {

                x = 120*4 + x;
                enemies.push( n, CreateEnemy(1, x, y) );
            }
            else
            {
                x = 250*2 + 300*n;
                enemies.push( n, CreateEnemy(2, x, y) );
            }
        }
        break;

    case 2:

        y = 800;

        for (int n = 0; n < 6; n++)
        {
            if ( n % 2 == 0 )
            {
                x = 120*2 + x;
                enemies.push( n + 5, CreateEnemy(1, x, y) );
            }
            else
            {
                x = 250 + 300*n;
                enemies.push( n + 5, CreateEnemy(2, x, y) );
            }
        }
        break;

    case 3:

        y = 1400;

        for ( int n = 0; n < 3; n++ )
        {
            if ( n % 2 == 0 )
            {
                x = 120*2 + 250*n;
                enemies.push( n + 5 + 6, CreateEnemy(1, x, y) );
            }
            else
            {
                x = 250 + 300*n;
                enemies.push( n + 5 + 6, CreateEnemy(2, x, y) );
            }
        }

        //x = 2096 - 400;
        x = 700;
        y = 400;
        enemies.push( 3 + 5 + 6, CreateEnemy(3, x, y) );
        break;

    default:
        break;

    }
}

void ObjectFactory::RenderAllEnemies()
{
    for (int i = 0; i < enemies.GetSize(); i++)
    {
        enemies.getElement(i)->Render();
    }
}

ObjectFactory::~ObjectFactory()
{
    //delete enemies;
}

bool ObjectFactory::IsTouching(MovingObject* e1, Enemy* e2)
{
    if (e1->GetX() - e2->GetX() < 50 && e1->GetX() - e2->GetX() > -50)
    {
        if (e1->GetY() == e2->GetY())
        {
            return true;
        }
    }
    return false;
}

void ObjectFactory::MoveAll(int val)
{
    for (int i = 0; i < enemies.GetSize(); i++)
    {
        enemies.getElement(i)->SetX( enemies.getElement(i)->GetX() + val );
    }
}

void ObjectFactory::TrackEverything(Player* gamePlayer)
{
    int num = enemies.GetSize();

    if (num == 0)
    {
        return;
    }

    for (int i = 0; i < num; i++)
    {
        for (int j = 0; j < num; j++)
        {
            if (i == j)
            {
                continue;
            }
            if (IsTouching(enemies.getElement(i), enemies.getElement(j)))
            {
                if (i > j)
                {
                    if (enemies.getElement(i)->GetType() != 0)
                    {
                        enemies.getElement(i)->SetX(enemies.getElement(i)->GetX() - 1);
                    }
                }
                else
                {
                    if (enemies.getElement(i)->GetType() != 0)
                    {
                        enemies.getElement(i)->SetX(enemies.getElement(i)->GetX() - 1);
                    }
                }
            }
        }

        if (enemies.getElement(i)->GetAlive())
        {
            enemies.getElement(i)->Move(1);
            enemies.getElement(i)->Track(gamePlayer, 1);
        }

        else if (!enemies.getElement(i)->GetAlive())
        {
           enemies.getElement(i)->Track(gamePlayer, 0);
        }
    }
}

Enemy* ObjectFactory::CreateEnemy(int choice, int x, int y)
{
    // 1 for chotu, 2 for medium, 3 for baru
    switch (choice)
    {
    case 1:
        return new Chota_Enemy( &chotuSpriteSheet, x, y, 130, 151, 191 );
        break;

    case 2:
        return new Medium_Enemy( &mediumSpriteSheet, x, y, 155, 0, 100 );
        break;

    case 3:
        return new Bara_Enemy( &baruSpriteSheet, x, y, 11, 15, 19 );
        break;

    default:
        break;
    }
}
