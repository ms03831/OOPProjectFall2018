#include "Game.h"
#include "TextureManager.h"
#include <fstream>

int Game::floor = 1;
int Game::frames = 0;
SDL_Renderer* Game::renderer = nullptr;

//constructor
Game::Game(const char* title, int xpos, int ypos, int width, int height, bool fullscrn)
{
    //Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
    }
    else
    {
        //Set texture filtering to linear
        if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
        {
            printf( "Warning: Linear texture filtering not enabled!" );
        }

        //Create window
        window = SDL_CreateWindow( "Paasbaan-e-Zafar", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, width, height, SDL_WINDOW_ALWAYS_ON_TOP);
        if( window == nullptr )
        {
            printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );

        }
        else
        {
            //Get window surface
            gScreenSurface = SDL_GetWindowSurface( window );

            //Create renderer for window
            renderer = SDL_CreateRenderer( window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
            if( renderer == nullptr )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );

            }
            else
            {
                //Initialize renderer color
                SDL_SetRenderDrawColor( Game::renderer, 0xFF, 0xFF,0xFF,0xFF );

                //Initialize PNG loading
                int imgFlags = IMG_INIT_PNG;
                if( !( IMG_Init( imgFlags ) & imgFlags ) )
                {
                    printf( "SDL_image could not initialize! SDL_mage Error: %s\n", IMG_GetError() );

                }
            }
        }
    }

    player  = nullptr;
    allEnemies = nullptr;
    zafar = nullptr;
    //init player at 1800-200 == 1600 then each time floor is changed do y -= 400
    Init(title, 0, 400, width, height, fullscrn);

}

void Game::LoadMedia()
{
    //Player sprite
    if(!pSpriteSheet.LoadFromFile( "final_kallu.png", Game::renderer ) )
    {
        printf( "Failed to load sprite sheet texture P!\n" );
    }

    if(!zSpriteSheet.LoadFromFile( "zafar.png", Game::renderer ) )
    {
        printf( "Failed to load sprite sheet texture Z!\n" );
    }
}

void Game::Init(const char* title, int xpos, int ypos, int width, int height, bool fullscrn)
{
    //makes a new game
    isRunning = true;

    bg = TextureManager::LoadTexture( "apnadungeon1.png", renderer );

    cout<< "GAME RUNNING";
    player = new Player(&pSpriteSheet, xpos, ypos, 0, 0, 0);
    zafar = new Zafar(&zSpriteSheet, 800, 600, 0, 0, 0);
    allEnemies = new ObjectFactory();

}

bool Game::CheckCollision(SDL_Rect a, SDL_Rect b)
{
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    leftA = a.x;
    rightA = a.x + a.w;
    topA = a.y;
    bottomA = a.y + a.h;

    leftB = b.x;
    rightB = b.x + b.w;
    topB = b.y;
    bottomB = b.y + b.h;

    if(bottomA <= topB)
    {
        return false;
    }

    if(topA >= bottomB)
    {
        return false;
    }

    if(rightA <= leftB)
    {
        return false;
    }

    if(leftA >= rightB)
    {
        return false;
    }

    return true;
}

void Game::HandleEvents()
{
    if (zafar->GetSafe() && player->GetAlive())// && player->win)
    {
        cout << "You Win" << endl;
    }
    //health in bounds
    for (int i = 0; i < allEnemies->GetList().GetSize(); i++)
    {
        if (allEnemies->GetList().getElement(i)->GetHealth() > 20)
        {
            allEnemies->GetList().getElement(i)->SetHealth(20);
        }

        else if (allEnemies->GetList().getElement(i)->GetHealth() < 0)
        {
            allEnemies->GetList().getElement(i)->SetHealth(0);
        }
    }

    if (player->GetHealth() > 20)
        player->SetHealth(20);

    else if (player->GetHealth() < 0)
        player->SetHealth(0);

    SDL_Event event;

    while (SDL_PollEvent(&event) != 0)
    {
        cout << "CALLED " << endl;
        if (event.type == SDL_QUIT)
        {
            isRunning = false;
            break;
        }

        else if (event.type == SDL_KEYDOWN)
        {
            if (camera.x < 0)
                camera.x = 0;

            else if (camera.x + camera.w > 800)
                camera.x = 800 - camera.w;


            switch (event.key.keysym.sym )
            {
            case SDLK_RIGHT:
                player->Move(0);
                if (camera.x + camera.w < 800)
                {
                    player->Move(-1);
                    camera.x += 1;
                    allEnemies->MoveAll(-1);
                }
                break;

            case SDLK_d:
                player->Move(0);
                if (camera.x + camera.w < 800)
                {
                    player->Move(-1);
                    camera.x += 1;
                    allEnemies->MoveAll(-1);
                }
                break;

            case SDLK_a:
                player->Move(1);
                if (camera.x > 0)
                {
                    player->Move(-2);
                    camera.x -= 1;
                    allEnemies->MoveAll(1);
                }
                break;

            case SDLK_LEFT:
                player->Move(1);
                if (camera.x > 0)
                {
                    player->Move(-2);
                    camera.x -= 1;
                    allEnemies->MoveAll(1);
                }
                break;

            case SDLK_LCTRL:
                player->Move(2);
                for (int i = 0; i < allEnemies->GetList().GetSize(); i++)
                {
                    if (CheckCollision(*player->GetDrect(), *allEnemies->GetList().getElement(i)->GetDrect()))
                    {
                        if (allEnemies->GetList().getElement(i)->GetHealth() != 0)
                        {
                            allEnemies->GetList().getElement(i)->ReduceHealth(allEnemies->GetList().getElement(i)->GetType());
                        }
                        if (allEnemies->GetList().getElement(i)->GetHealth() == 0)
                        {
                            allEnemies->GetList().getElement(i)->SetAlive(false);
                            //player->score += allEnemies->GetList().getElement(i)->GetType();
//                            if (allEnemies->GetList().getElement(i)->GetType() == 2 && player->currentW == 1)
//                            {
//                                player->ChangeWeapon(2);
//                            }
                        }
                    }
                }
                cout << "ATTACKKKK" << endl;
                break;

            case SDLK_UP:
                if (player->GetX() > 700 && player->GetX() < 800 && player->GetFloor()%2 == 1)
                {
                    player->Move(10);
                    floor++;
                    if (player->GetFloor() < 4)
                        {
                            camera.y -= 400;
                        }
                }

                else if ( player->GetX() > 0 && player->GetX() < 100 && player->GetFloor()%2 == 0 )
                {
                    floor++;
                    player->Move(10);
                    if (player->GetFloor() < 4)
                        {
                            camera.y -= 400;
                        }
                }
                break;

            case SDLK_0:
                player->SetHide(true);
                break;
            case SDLK_1:
                player->SetHide(false);
                break;

            case SDLK_m:
//                if (Mix_PausedMusic() == 1)
//                {
//                    //Resume the music
//                    Mix_ResumeMusic();
//                }
//                //If the music is playing
//                else
//                {
//                    //Pause the music
//                    Mix_PauseMusic();
//                }
                break;

            default:
                break;
            }

        }

        else if (event.type == SDL_KEYUP)
        {
            player->Move(3);
        }

    }

    allEnemies->TrackEverything(player);

    }

void Game::Render()
{
    frames++;
    SDL_RenderClear(renderer);
    //SDL_RenderCopy(renderer, bg, nullptr, nullptr);
    SDL_RenderCopy(renderer, bg, &camera, nullptr);
    player->Render();
    allEnemies->RenderAllEnemies();
    SDL_RenderPresent(renderer);
}

void Game::Clear()
{
    player = nullptr;
    delete player;
    allEnemies = nullptr;
    delete allEnemies;
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    cout << "Game screen is now cleared and memory is deallocated" << endl;
}
