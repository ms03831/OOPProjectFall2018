#pragma once

#include "MovingObject.h"
#include "Player.h"


class Enemy : public MovingObject
{
    public:
        /** Default constructor */
        Enemy();
        /** Default destructor */
        virtual ~Enemy();
        /** Overloaded constructor */
        //Enemy(const char* textureSheet, int x, int y, int R, int G, int B);
        Enemy(LTexture* textureSheet, int x, int y, int R, int G, int B);
        /** Access range
         * \return The current value of range
         */
        int GetRange();// { return range; }
        /** Set range
         * \param val New value to set
         */
        void SetRange(int val);// { range = val; }

        int GetStartX();// { return this->startX; }

        void SetStartX(int val);// { this->startX = val; }

        /** Move: Dictates how the enemy moves on screen
         * Pure virtual as different enemies move differently.
         */
        virtual void Move(int) = 0;

        /** Attack: Dictates how the enemy attacks the player
         * Pure virtual as different enemies attack differently.
         */
        virtual void Attack(Player*) = 0;

        /** PlayerInRange(Player*):
        * Checks if player is in the range of movement of enemy.
        */
        bool PlayerInRange(Player*);

        /** Track(MovingObject&, bool):
        * Tracks the MovingObject, if enemy alive then bool is true and enemy move towards the player if certain conditions satisfied else
        no movement
        */

        int DangerZone();

        virtual void Track(Player*, bool);

        void Render();

        /** IsPlayerInZone(Player*):
         * Checks if the player is in zone.
        */
        bool PlayerInZone(Player*);

        void SetType(int val)
        {
            this->type = val;
        }

        int GetType()
        {
            return this->type;
        }

        void SetEnemySize(int type); //sets size (width, height of destrect) acc to type of enemy

        void ReduceHealth(int wtype); //Reduces health depending on the type of enemy

        void ChangeAnimation(); //changes the renderrect back to walkingrect

        bool CheckCollision(Player* player); //checks collision btw player and enemy

    protected:
        int attack; //to keep track of when to change the sprite in case enemy attacks

    private:
        int range; //!< Member variable "range": a defined radius in which the enemy moves
        int type; //type of enemy
        int startX; //starting x position of enemy

};

