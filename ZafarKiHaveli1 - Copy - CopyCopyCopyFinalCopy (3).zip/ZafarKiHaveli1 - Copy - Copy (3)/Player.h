#pragma once
#include "SDL.h"
#include "LTexture.h"
#include "MovingObject.h"


class Player: public MovingObject
{
public:
    Player(LTexture* textureSheet, int x, int y, int R, int G, int B);
    ~Player();
    void Move(int);
    void Render();
    void ChangeFloor();

//    void ChangeWeapon(int type);

    bool GetIdle()
    {
        return this->idle;
    }

    void SetIdle(bool idle)
    {
        this->idle = idle;
    }

    bool IsHiding()
    {
        return this->isHiding;
    }

    void SetHide(bool hide)
    {
        this->isHiding = hide;
    }

private:
    bool idle;
    bool isHiding;

};
