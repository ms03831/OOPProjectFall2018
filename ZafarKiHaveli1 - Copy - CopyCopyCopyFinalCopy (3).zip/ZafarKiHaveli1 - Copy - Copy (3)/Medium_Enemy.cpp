#include "Medium_Enemy.h"

Medium_Enemy::Medium_Enemy(LTexture* textureSheet, int x, int y, int R, int G, int B):Enemy( textureSheet, x, y, R, G, B)
{
    this->SetRange( 250 );
    this->SetType( 2 );
    this->SetEnemySize( this->GetType() );
    this->attackingRect = new SDL_Rect[8];
    //ATTACK ANIMATION
    this->attackingRect[0].x = 0;
    this->attackingRect[0].y = 320;

    for (int i = 0; i < 8; i++)
    {
        this->attackingRect[i].w = 64;
        this->attackingRect[i].h = 64;
        this->attackingRect[i].x = this->attackingRect[0].x + i*this->attackingRect[0].w;
        this->attackingRect[i].y = this->attackingRect[0].y;
    }
}

void Medium_Enemy::Move( int y )
{
    if (this->GetAlive())
    {
        if (this->GetDirection() == 1)
        {
            this->flip = SDL_FLIP_HORIZONTAL;
            this->SetVelocity(1);
        }

        else if (this->GetDirection() == -1)
        {
            this->flip = SDL_FLIP_NONE;
            this->SetVelocity(-1);
        }


        if (this->GetStartX() == this->GetX())
        {
            this->SetDirection(-1);
        }

        else if (this->GetStartX() - this->GetRange() == this->GetX())
        {
            this->SetDirection(1);
        }

        this->SetX( this->GetX() + this->GetVelocity() );
        //this->Attack(nullptr);
    }
}

void Medium_Enemy::Attack(Player* player)
{
    this->attack = 1;
    delete[] this->renderRect;
    this->divFrames = 8;
    this->renderRect = new SDL_Rect[this->divFrames];

    for (int i = 0; i < this->divFrames; i++)
    {
        this->renderRect[i] = this->attackingRect[i];
    }

    player->ReduceHealth(this->GetType());
}

void Medium_Enemy::Track(Player* player, bool alive)
{
    if (alive)
    {
        if (PlayerInZone(player))
        {
            if (!player->IsHiding())
            {
                if ((this->GetDirection() == -1 && this->GetFloor()%2 == 1) ||
                    (this->GetDirection() == 1 && this->GetFloor()%2 == 0))
                {
                    if (this->CheckCollision(player))
                    {
                        this->Attack(player);
                    }
                    else
                    {
                        this->SetX( this->GetX() + this->GetVelocity() );
                    }
                }
            }
        }
    }
}

Medium_Enemy::~Medium_Enemy()
{
    //dtor
}
