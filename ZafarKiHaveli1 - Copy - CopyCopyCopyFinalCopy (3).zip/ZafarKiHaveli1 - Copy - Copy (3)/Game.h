#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "EnemyFactory.h"
#include "LTexture.h"
#include "Player.h"
#include "Enemy.h"
#include "Zafar.h"
#include <iostream>

class ObjectFactory;

using namespace std;

class Game
{
public:
    Game(const char* title, int xpos, int ypos, int width, int height, bool fullscrn);
    ~Game() {}
    void Init(const char* title, int xpos, int ypos, int width, int height, bool fullscrn);
    void HandleEvents();
    void Render();
    void Clear();
    void LoadMedia();
    bool CheckCollision();
    bool CheckCollision(SDL_Rect a, SDL_Rect b);
    bool Running()
    {
        return isRunning;
    }

    static SDL_Renderer* renderer;

    static int frames;

    static int floor;

private:

    bool alive = true;
    int input = 0;
    bool isRunning;

    Player* player;
    ObjectFactory* allEnemies;
    Zafar* zafar;

    SDL_Window* window = nullptr; //The window we'll be rendering to
    SDL_Surface* gScreenSurface = nullptr; //The surface contained by the window
    SDL_Texture* bg = nullptr;
    SDL_Rect camera = {0, 0, 800, 600};
    LTexture pSpriteSheet; //Player sprite sheet
    LTexture zSpriteSheet; //Zafar sprite sheet
};
