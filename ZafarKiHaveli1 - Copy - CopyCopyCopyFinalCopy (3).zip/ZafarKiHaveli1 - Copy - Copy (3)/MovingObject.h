#ifndef MOVINGOBJECT_H
#define MOVINGOBJECT_H
#include <SDL.h>
#include "LTexture.h"
#include <stdio.h>

class MovingObject
{
    public:
        /** Default constructor */
        MovingObject();
        /** Default destructor */
        virtual ~MovingObject();

        /** Overloaded constructor */
        MovingObject(LTexture* textureSheet, int x, int y, int R, int G, int B);

        /** Access Xpos;return The current value of Xpos*/
        int GetX()
        {
            return xPos;
        }

        /** Set Xpos param val New value to set*/
        void SetX(int val)
        {
            xPos = val;
        }
        /** Access yPos return The current value of yPos*/
        int GetY()
        {
            return yPos;
        }

        /** Set yPos \param val New value to set */
        void SetY(int val)
        {
            yPos = val;
        }

        /** Access srcRect.return The current address of srcRect*/
        SDL_Rect* GetSrect()
        {
            return renderRect;
        }

        /** Access dstRect-return The current address of dstRect*/
        SDL_Rect* GetDrect()
        {
            return &destRect;
        }

        void SetDrect(SDL_Rect val)
        {
            destRect.x = val.x;
            destRect.y = val.y;
            destRect.w = val.w;
            destRect.h = val.h;
        }

        /** Access alive-return The current value of alive*/
        bool GetAlive()
        {
            return this->alive;
        }
        /** Set alive. New value to set*/
        void SetAlive(bool val)
        {
            this->alive = val;
        }

        virtual void Move( int ) = 0;

        virtual void Render() = 0;

        void SetDirection(int val)
        {
            //1 for right, -1 for left
            this->direction = val;
        }

        int GetDirection()
        {
            return this->direction;
        }

        void SetVelocity(int val)
        {
            this->velocity = val;
        }

        int GetVelocity()
        {
            return this->velocity;
        }

        int GetHealth()
        {
            return health;
        }

        void SetHealth(int val)
        {
            this->health = val;
        }

        void ReduceHealth( int type = 0 );

        int GetFloor();

        virtual void RenderHealth();

        LTexture* GetOTexture()
        {
            return oTexture;
        }

        void SetOTexture(LTexture* texture)
        {
            this->oTexture = texture;
        }

        void ChangeSpriteIndex(int);

        int GetSpriteIndex()
        {
            return this->spriteIndex;
        }


    protected:
        int divFrames = 9;
        SDL_Rect* walkingRect;
        SDL_Rect* attackingRect;
        SDL_Rect* renderRect;
        SDL_Rect destRect;
        SDL_RendererFlip flip = SDL_FLIP_NONE; //!<to flip a sprite, initially the orientation is none

    private:
        int xPos; //!< Member variable "Xpos"
        int yPos; //!< Member variable "Ypos"
        int spriteIndex;
        int health;
        int velocity;
        int direction;
        SDL_Texture* healthtex;
        bool alive; //!< Member variable "alive"
        LTexture* oTexture; //!<to load and save the texture
};

#endif // MOVINGOBJECT_H
