#pragma once
#include "Enemy.h"

class Medium_Enemy : public Enemy
{
    public:
        /** Default constructor */
        Medium_Enemy();

        /** Default destructor */
        virtual ~Medium_Enemy();

        /** Overloaded destructor */
        Medium_Enemy(LTexture* textureSheet, int x, int y, int R, int G, int B);

        /** Move(int flag):
        * Dictates the movement of Medium_Enemy
        */
        void Move(int);

        /** Attack(Player*):
        * Dictates how the Medium_Enemy attacks the player (animation of attack and
                                                            health deduction)
        */
        void Attack(Player*);

        /** Tracks the MovingObject, if enemy alive then bool is true and enemy moves towards the player
        if certain conditions satisfied else no movement
        */
        void Track(Player*, bool);

    protected:

    private:
};
