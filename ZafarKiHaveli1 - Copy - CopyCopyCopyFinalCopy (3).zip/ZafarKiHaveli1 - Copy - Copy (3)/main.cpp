#include <iostream>
#include "Game.h"
#include "Player.h"
#include <time.h>
#include <cstdlib>

Game* game = nullptr;

int main( int argc, char* args[] )
{
    srand( (time(nullptr)) );

    const int FPS = 60;
    const int frameDelay = 1000 / FPS;

    Uint32 frameStart;
    int frameTime;
    game = new Game("Paasbaan-e-Zafar", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1200, 600, true);

    game->LoadMedia();

    while (game->Running())
    {
        frameStart = SDL_GetTicks();

        game->HandleEvents();
        game->Render();

        frameTime = SDL_GetTicks() - frameStart;

        if (frameDelay > frameTime)
        {
            SDL_Delay(frameDelay - frameTime);
        }
    }

    game->Clear();

    std::cout << "Hello world!" << std::endl;
    return 0;
}
