#pragma once
#include <iostream>

template<typename T>
class Node
{
public:
    /** Default constructor */
    Node<T>()
    {
        prev = NULL;
        next = NULL;
    }

    T data; // change this to type template
    Node<T>* prev;
    Node<T>* next;
    int index;

    /** Default destructor */
    virtual ~Node<T>()
    {
        delete prev;
        delete next;
    }
};
