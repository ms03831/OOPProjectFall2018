#include "Bara_Enemy.h"
#include <iostream>

Bara_Enemy::Bara_Enemy(LTexture* textureSheet, int x, int y, int R, int G, int B):Enemy( textureSheet, x, y, R, G, B)
{
    this->SetRange( 400 );
    this->SetType( 3 );
    this->SetEnemySize( this->GetType() );
    this->attackingRect = new SDL_Rect[10];
    //ATTACK ANIMATION
    this->attackingRect[0].x = 0;
    this->attackingRect[0].y = 1088;

    for (int i = 0; i < 10; i++)
    {
        this->attackingRect[i].w = 64;
        this->attackingRect[i].h = 64;
        this->attackingRect[i].x = this->attackingRect[0].x + i*this->attackingRect[0].w;
        this->attackingRect[i].y = this->attackingRect[0].y;
    }
}

void Bara_Enemy::Move( int x )
{
    if (this->GetAlive())
    {
        if (this->GetDirection() == 1)
        {
            flip = SDL_FLIP_HORIZONTAL;
            this->SetVelocity(1);
        }

        else if (this->GetDirection() == -1)
        {
            flip = SDL_FLIP_NONE;
            this->SetVelocity(-1);
        }


        if (this->GetStartX() == this->GetX())
        {
            this->SetDirection(-1);
        }

        else if (this->GetStartX() - this->GetRange() == this->GetX())
        {
            this->SetDirection(1);
        }

        this->SetX( this->GetX() + this->GetVelocity() );
        this->Attack(nullptr);
    }
}

void Bara_Enemy::Attack(Player* player)
{
    this->attack = 1;
    delete[] this->renderRect;
    this->divFrames = 10;
    this->renderRect = new SDL_Rect[this->divFrames];

    for (int i = 0; i < this->divFrames; i++)
    {
        this->renderRect[i] = this->attackingRect[i];
    }
    //reduce health in Arrow
}

void Bara_Enemy::Track(Player* player, bool alive)
{
    if (alive)
    {
        if (PlayerInZone(player))
        {
            if (!player->IsHiding())
            {
                if ((this->GetDirection() == -1 && this->GetFloor()%2 == 1) ||
                    (this->GetDirection() == 1 && this->GetFloor()%2 == 0))
                {
                    if ((this->GetFloor()%2 == 1 && player-> GetX() > this->GetX() + 300*this->GetDirection()) ||
                        (this->GetFloor()%2 == 0 && player-> GetX() < this->GetX() + 300*this->GetDirection()))//300 is arrow's range
                    {
                        this->Attack(player);
                    }

                    else
                    {
                        this->SetX( this->GetX() + this->GetVelocity() );
                    }
                }
            }
        }
    }

}


Bara_Enemy::~Bara_Enemy()
{
    //dtor
}
