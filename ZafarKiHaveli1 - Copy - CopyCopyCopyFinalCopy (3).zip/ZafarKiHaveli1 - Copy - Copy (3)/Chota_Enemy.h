#include "Enemy.h"
#include "Player.h"


class Chota_Enemy : public Enemy
{
    public:
        /** Default constructor */
        Chota_Enemy();
        /** Default destructor */
        virtual ~Chota_Enemy();
        /** Overloaded destructor */
        Chota_Enemy(LTexture* textureSheet, int x, int y, int R, int G, int B);
        /** Move(int flag):
        * Dictates the movement of Chota_Enemy
        */
        void Move(int);
        /** Attack(Player*):
        * Dictates how the Chota_Enemy attacks the player(animation of attack and
                                                            health deduction)
        */
        void Attack(Player*);

        /** Tracks the MovingObject, if enemy alive then bool is true and enemy move towards the player
        if certain conditions satisfied else no movement
        */
        void Track(Player*, bool);


    protected:

    private:
};
