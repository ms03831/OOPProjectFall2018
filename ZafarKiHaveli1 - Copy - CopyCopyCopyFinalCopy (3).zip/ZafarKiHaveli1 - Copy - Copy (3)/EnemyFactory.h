#pragma once
#include "Game.h"
#include "MovingObject.h"
#include "Enemy.h"
#include "LinkedList.h"
#include "Chota_Enemy.h"
#include "Medium_Enemy.h"
#include "Bara_Enemy.h"
#include <sstream>
#include <cstdlib>
#include <string>

using namespace std;

class ObjectFactory
{
private:

    LTexture chotuSpriteSheet;
    LTexture baruSpriteSheet;
    LTexture mediumSpriteSheet;

    LinkedList <Enemy*> enemies; //all the objects in this list

public:

    ObjectFactory();
    //ObjectFactory(somedatatype load); //overloaded for positions of the previous game

    void GenerateEnemiesFloor(int floor);
    void TrackEverything(Player* player);
    void RenderAllEnemies();
    void MoveAll(int);
    Enemy* CreateEnemy(int type, int x, int y);

    LinkedList <Enemy*> &GetList()
    {
        return enemies;
    }

    bool IsTouching(MovingObject* e1, Enemy* e2);//for repulsions detection

    ~ObjectFactory();

};
