#include "DungeonObject.h"
#include <iostream>

using namespace std;

DungeonObject::DungeonObject(const char* filename, SDL_Renderer* ren, Position sourcePos, int sourceWidth,
                             int sourceHeight, Position destPos, int destWidth, int destHeight)
{
    this->texture = TextureManager::LoadTexture(filename, ren);
    this->renderer = ren;
    this->pos = destPos;

    // set frame rate
    frameRate = 0;
    // set running time
    runTime = 0;
    display = false;
    animate = false;

    //set rects
    sourceRect.h = sourceHeight;
    sourceRect.w = sourceWidth;
    sourceRect.x = sourcePos.x;
    sourceRect.y = sourcePos.y;

    destRect.h = destHeight;
    destRect.w = destWidth;
    destRect.x = destPos.x;
    destRect.y = destPos.y;
}

void DungeonObject::render()
{
    SDL_RenderCopy(renderer, texture, &sourceRect, &destRect);
    frameRate++;
}

SDL_Texture* DungeonObject::getTexture()
{
    return texture;
}

SDL_Rect DungeonObject::getSourceRect()
{
    return sourceRect;
}

SDL_Rect DungeonObject::getDestRect()
{
    return destRect;
}

void DungeonObject::setDestRect(SDL_Rect newDest)
{
    destRect = newDest;
}

SDL_Renderer* DungeonObject::getRenderer()
{
    return renderer;
}

Position DungeonObject::getPosition()
{
    return pos;
}

void DungeonObject::setPosition(Position p)
{
    this->pos = p;
    destRect.x = pos.x;
    destRect.y = pos.y;
}

Uint32 DungeonObject::getFrameRate()
{
    return frameRate;
}

void DungeonObject::setFrameRate(Uint32 frame)
{
    frameRate = frame;
}

void DungeonObject::setSourceRect(SDL_Rect s)
{
    sourceRect = s;
}

int* DungeonObject::getSprites()
{
    return sprites;
}

bool DungeonObject::getDisplay()
{
    return display;
}

void DungeonObject::setDisplay(bool val)
{
    display = val;
}

void DungeonObject::setRunTime(double r)
{
    runTime = r;
}

double DungeonObject::getRunTime()
{
    return runTime;
}

bool DungeonObject::getAnimate()
{
    return animate;
}

void DungeonObject::setAnimate(bool s)
{
    animate = s;
}
