#ifndef ZAFAR_H
#define ZAFAR_H

#include "MovingObject.h"

#include "LTexture.h"


class Zafar : public MovingObject
{
    public:
        /** Default constructor */
        Zafar();
        /** Default destructor */
        virtual ~Zafar();
        /** Overloaded constructor */
        Zafar(LTexture* textureSheet, int x, int y, int R, int G, int B);

        /** Access safe
         * \return The current value of safe
         */
        bool GetSafe() { return safe; }
        /** Set safe
         * \param val New value to set
         */
        void SetSafe(bool val) { safe = val; }
        /** Access room
         * \return The current coordinates of room as SDL_Rect
         */
        SDL_Rect GetRoomCord() { return room; }
        /** Set room
         * \param val New value to set
         */
        void SetRoom(SDL_Rect val) { room = val; }
        /** Move(int flag):
        * Dictates the movement of Zafar: one thing to note here is that Zafar can only move with the player i.e. only after
        hes been saved.
        */
        void Move(int){}
        /** bool CanMove:
        * Checks if Zafar is with Player(safe) in that case it returns true else false.
        */
        bool CanMove();

        void Render(){}

    protected:

    private:
        LTexture* zafarTex;
        SDL_Rect idleRect;
        SDL_Rect walkingRect[4];
        SDL_Rect* renderRect;
        SDL_Rect destRect;
        bool safe; //!< Member variable "safe"
        SDL_Rect room; //!< Member variable "room"
};

#endif // ZAFAR_H
