#include "Enemy.h"
#include "TextureManager.h"
#include "Game.h"

Enemy::Enemy(LTexture* textureSheet, int x, int y, int R, int G, int B):MovingObject(textureSheet, x, y, R, G, B)
{
    this->attack = 0;
    this->SetDirection(-1);
    this->SetStartX(x);
    this->divFrames = 9;
    this->walkingRect = new SDL_Rect[9];

    //WALKING ANIMATION
    this->walkingRect[0].x = 0;
    this->walkingRect[0].y = 580;

    for (int i = 0; i < 9; i++)
    {
        this->walkingRect[i].w = 64;
        this->walkingRect[i].h = 64;
        this->walkingRect[i].x = this->walkingRect[0].x + i*this->walkingRect[0].w;
        this->walkingRect[i].y = this->walkingRect[0].y;
    }

    this->renderRect = new SDL_Rect[this->divFrames];

    for (int i = 0; i < this->divFrames; i++)
    {
        this->renderRect[i] = this->walkingRect[i];
    }

    this->SetDrect(this->destRect);
}

void Enemy::SetEnemySize(int type) //sets size (width, height of destrect) acc to type of enemy
{
    switch( type )
    {
    case 1:
        this->destRect.w = this->renderRect[0].w*2;
        this->destRect.h = this->renderRect[0].h*2;
        this->destRect.x = this->GetX();
        this->destRect.y = this->GetY() - this->destRect.h + 16;
        break;

    case 2:
        this->destRect.w = this->renderRect[0].w*2.5;
        this->destRect.h = this->renderRect[0].h*2.5;
        this->destRect.x = this->GetX();
        this->destRect.y = this->GetY() - this->destRect.h + 16;
        break;

    case 3:
        this->destRect.w = this->renderRect[0].w*3;
        this->destRect.h = this->renderRect[0].h*3;
        this->destRect.x = this->GetX();
        this->destRect.y = this->GetY() - this->destRect.h + 16;
        break;

    default:
        break;
    }
}

void Enemy::Render()
{
    //frames++;
    //this->Move(1);

    if (Game::frames % 5 == 0)
        this->ChangeSpriteIndex(this->divFrames);

    this->destRect.x = this->GetX();

    this->SetDrect(this->destRect);

    if (this->GetAlive())
    {
        this->GetOTexture()->Render(&this->renderRect[ this->GetSpriteIndex() ], &this->destRect, 0.0, nullptr, this->flip, Game::renderer);
    }

    this->RenderHealth();

    if (this->attack == 1)
    {
        //this->ChangeAnimation();
        if (this->GetType() == 3)
        {
            ///Arrow fire kar
            //Arrow* arrow = new Arrow(args);
            //arrow->update() and render();
            //delete arrow;
        }
        this->attack = 0;
    }
}

bool Enemy::CheckCollision(Player* player)
{
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    leftA = this->destRect.x;
    rightA = this->destRect.x + this->destRect.w;
    topA = this->destRect.y;
    bottomA = this->destRect.y + this->destRect.h;

    leftB = player->GetDrect()->x;
    rightB = player->GetDrect()->x + player->GetDrect()->w;
    topB = player->GetDrect()->y;
    bottomB = player->GetDrect()->y + player->GetDrect()->h;

    if(bottomA <= topB)
    {
        return false;
    }

    if(topA >= bottomB)
    {
        return false;
    }

    if(rightA <= leftB)
    {
        return false;
    }

    if(leftA >= rightB)
    {
        return false;
    }

    return true;
}

void Enemy::ReduceHealth(int type)
{
    if ( this->GetHealth() == 0 )
    {
        this->SetAlive(false);
    }

    else
    {
        switch( type )
        {
        case 1: //Chota enemy
            this->SetHealth(this->GetHealth() - 4);
            break;
        case 2: //Medium Enemy
            this->SetHealth(this->GetHealth() - 2);
            break;
        case 3: //bara enemy
            this->SetHealth(this->GetHealth() - 1);
            break;
        default:
            break;
        }
    }
}

int Enemy::GetRange()
{
    return range;
}

void Enemy::SetRange(int val)
{
     range = val;
}

int Enemy::GetStartX()
{
    return this->startX;
}

void Enemy::SetStartX(int val)
{
    this->startX = val;
}

bool Enemy::PlayerInRange(Player* player)
{
    if (player->GetFloor() == this->GetFloor())
    {
        if (player->GetX() > this->GetStartX() - this->GetRange())
        {
            return true;
        }
    }
    return false;
}

void Enemy::Track(Player* p, bool alive){}

int Enemy::DangerZone()
{
    return this->GetX() - this->GetRange();
}

bool Enemy::PlayerInZone(Player* player)
{
    if ( this->PlayerInRange(player) )
    {
        return true;
    }
    if ( player->GetX() > this->DangerZone() )
    {
        return true;
    }
    else
    {
        return false;
    }
}


void Enemy::ChangeAnimation()
{
    this->divFrames = 9;
    delete[] this->renderRect;
    this->renderRect = new SDL_Rect[this->divFrames];
    for (int i = 0; i < this->divFrames; i++)
    {
        this->renderRect[i] = this->walkingRect[i];
    }
}

Enemy::~Enemy()
{

}
