#pragma once
#include "DungeonObject.h"

class Traps: public DungeonObject
{
public:
    Traps(){}
    /** Overloaded constructor */
    Traps(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){}
    /** Default destructor */
    virtual ~Traps(){}

    void Interaction();
};
