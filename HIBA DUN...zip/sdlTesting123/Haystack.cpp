#include "Haystack.h"

void Haystack::Interaction()
{
    animate = true;
}

void Haystack::update()
{
    if (runTime==spritesNumber)
        animate = false;

    if (getFrameRate() % 140 == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        r.y = sprites[(int)runTime];
        setSourceRect(r);
        runTime++;
    }
}
