#pragma once
#include <iostream>

template<typename T>
class Node
{
public:
    /** Default constructor */
    Node<T>()
    {
        next = NULL;
    }

    T data; // change this to type template
    Node<T>* next;
    int index;

    /** Default destructor */
    virtual ~Node<T>()
    {
        delete next;
    }
};
