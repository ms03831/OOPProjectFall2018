#include "Position.h"

Position::Position()
{
    x = 0;
    y = 0;
}

Position::Position(int x, int y)
{
    this->x = x;
    this->y = y;
}

Position Position::Set(int x, int y)
{
    Position pos(x,y);
    return pos;
}

Position::~Position()
{
    //
}
