#include "Traps.h"

void Traps::Interaction()
{
    //
}
