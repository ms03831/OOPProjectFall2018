#include "Door.h"

void Door::Interaction()
{
    //
}

void Door::update()
{
    if (getFrameRate() % 400 == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        int x = runTime;
        if (!doorOpen)
        {
            r.y = sprites[x];
            setSourceRect(r);
            runTime++;

            if (runTime == spritesNumber)
            {
                animate = false;
                doorOpen = true;
            }
        }
        else if (doorOpen)
        {
            r.y = sprites[0];
            setSourceRect(r);

            animate = false;
            doorOpen = false;
        }
    }
}
