#include "HealthPowerUp.h"

void HealthPowerUp::Interaction()
{
    //
}
