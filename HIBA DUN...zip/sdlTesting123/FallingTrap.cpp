#include "FallingTrap.h"

void FallingTrap::Interaction()
{
    //
}

SDL_Rect s;

void FallingTrap::update()
{
    if (getFrameRate() >= 1000 and getFrameRate() <= 1200)
    {
       FallBack();
    }
    if (getFrameRate() >= 1200)
    {
        Fall();
    }
}

void FallingTrap::FallBack()
{
    Position p;
    p = getPosition();
    p.y--;
    setPosition(p);
}

void FallingTrap::Fall()
{
    s.h = 88;
    s.w = 134;
    s.x = 0;
    s.y = sprites[1];
    setSourceRect(s);
    Position p;
    p = getPosition();
    p.y++;
    setPosition(p);
}
