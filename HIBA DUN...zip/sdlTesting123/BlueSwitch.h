#include "Switch.h"
#include "Door.h"

class BlueSwitch: public Switch
{
public:
    BlueSwitch(){}
    BlueSwitch(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Switch(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){
                                                           display = true;

                                                       }

     virtual ~BlueSwitch(){}

    /** Inherited pure virtual functions form abstract base class */
    void Interaction();
};
