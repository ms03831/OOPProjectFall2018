#pragma once
#include <iostream>
#include <cstdlib>
#include "Position.h"
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "TextureManager.h"

// base class for dungeon objects
class DungeonObject
{
private:
    Position pos;       // position of object

    Uint32 frameRate;
    SDL_Texture* texture;
    SDL_Rect sourceRect, destRect;
    SDL_Renderer* renderer;

    int ID;
protected:
    int* sprites;
    int spritesNumber;
    double runTime;
    bool goDestroy;     // object no longer needed, hence can be destroyed
    bool display;
    bool animate;
    bool direction;     // true means right and vice versa
    int startAnimation;

    DungeonObject* CONTROLLED_OBJECT;
public:
    DungeonObject(){}
    /** Overloaded constructor */
    DungeonObject(const char* filename, SDL_Renderer* ren, Position sourcePos,
                  int sourceWidth, int sourceHeight, Position destPos, int destWidth, int destHeight);
    /** Default destructor */
    virtual ~DungeonObject(){}

    virtual void update(){}
    virtual void render();

    /** Pure virtual functions */
    virtual void Interaction() = 0;         // if isCharacterInteracting(Position) returns true, this function determines nature of interaction

    /**  Collision detection */
    bool isCharacterInteracting(SDL_Rect);   // check whether player is behind/inside object: will be different for different objects

    /** Getters/Setters */
    void setID(int);
    int getID();
    SDL_Texture* getTexture();
    SDL_Rect getSourceRect();
    SDL_Rect getDestRect();
    SDL_Renderer* getRenderer();
    Position getPosition();
    Uint32 getFrameRate();
    void setTexture(SDL_Texture*);
    void setFrameRate(Uint32);
    void setPosition(Position);
    void setSourceRect(SDL_Rect);
    void setDestRect(SDL_Rect);
    int getSpriteAt(int);
    bool getDisplay();
    void setDisplay(bool);
    bool getAnimate();
    void setAnimate(bool);
    void setRunTime(double);
    double getRunTime();
    void setDirection(bool);
    Uint32 getStartAnimation();
    void setStartAnimation(Uint32);
    DungeonObject* getControlledObject();
    void setControlledObject(DungeonObject*);
    bool getGoDestroy();
    void setGoDestroy(bool);
};
