#include "DungeonObject.h"
#include <iostream>

using namespace std;

DungeonObject::DungeonObject(const char* filename, SDL_Renderer* ren, Position sourcePos, int sourceWidth,
                             int sourceHeight, Position destPos, int destWidth, int destHeight)
{
    this->texture = TextureManager::LoadTexture(filename, ren);
    this->renderer = ren;
    this->pos = destPos;

    // set frame rate
    frameRate = 0;
    // set running time
    runTime = 0;

    goDestroy = false;
    display = true;
    animate = false;
    direction = true;
    startAnimation = 0;

    //set rects
    sourceRect.h = sourceHeight;
    sourceRect.w = sourceWidth;
    sourceRect.x = sourcePos.x;
    sourceRect.y = sourcePos.y;

    destRect.h = destHeight;
    destRect.w = destWidth;
    destRect.x = destPos.x;
    destRect.y = destPos.y;

    //set controlled objects
    CONTROLLED_OBJECT = nullptr;
}

void DungeonObject::render()
{
    SDL_RenderCopy(renderer, texture, &sourceRect, &destRect);
    frameRate++;
}

bool DungeonObject::isCharacterInteracting(SDL_Rect secondObj)
{
    //The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    //Calculate the sides of rect firstObj
    leftA = destRect.x;
    rightA = destRect.x + destRect.w;
    topA = destRect.y;
    bottomA = destRect.y + destRect.h;

    //Calculate the sides of rect secondObj
    leftB = secondObj.x;
    rightB = secondObj.x + secondObj.w;
    topB = secondObj.y;
    bottomB = secondObj.y + secondObj.h;

    //If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        return false;
    }

    if( topA >= bottomB )
    {
        return false;
    }

    if( rightA <= leftB )
    {
        return false;
    }

    if( leftA >= rightB )
    {
        return false;
    }

    //If none of the sides from firstObj are outside secondObj
    return true;
}

void DungeonObject::setID(int id)
{
    ID = id;
}

int DungeonObject::getID()
{
    return ID;
}

SDL_Texture* DungeonObject::getTexture()
{
    return texture;
}

void DungeonObject::setTexture(SDL_Texture* t)
{
    texture = t;
}

SDL_Rect DungeonObject::getSourceRect()
{
    return sourceRect;
}

SDL_Rect DungeonObject::getDestRect()
{
    return destRect;
}

void DungeonObject::setDestRect(SDL_Rect newDest)
{
    destRect = newDest;
}

SDL_Renderer* DungeonObject::getRenderer()
{
    return renderer;
}

Position DungeonObject::getPosition()
{
    return pos;
}

void DungeonObject::setPosition(Position p)
{
    this->pos = p;
    destRect.x = pos.x;
    destRect.y = pos.y;
}

Uint32 DungeonObject::getFrameRate()
{
    return frameRate;
}

void DungeonObject::setFrameRate(Uint32 frame)
{
    frameRate = frame;
}

void DungeonObject::setSourceRect(SDL_Rect s)
{
    sourceRect = s;
}

int DungeonObject::getSpriteAt(int i)
{
    return sprites[i];
}

bool DungeonObject::getDisplay()
{
    return display;
}

void DungeonObject::setDisplay(bool val)
{
    display = val;
}

void DungeonObject::setRunTime(double r)
{
    runTime = r;
}

double DungeonObject::getRunTime()
{
    return runTime;
}

bool DungeonObject::getAnimate()
{
    return animate;
}

void DungeonObject::setAnimate(bool s)
{
    animate = s;
    if (s)
        runTime = 0;
}

void DungeonObject::setDirection(bool lr)
{
    direction = lr;
}

Uint32 DungeonObject::getStartAnimation()
{
    return startAnimation;
}

void DungeonObject::setStartAnimation(Uint32 s)
{
    startAnimation = s;
}

DungeonObject* DungeonObject::getControlledObject()
{
    return CONTROLLED_OBJECT;
}

void DungeonObject::setControlledObject(DungeonObject* o)
{
    CONTROLLED_OBJECT = o;
}

bool DungeonObject::getGoDestroy()
{
    return goDestroy;
}

void DungeonObject::setGoDestroy(bool s)
{
    goDestroy = s;
}
