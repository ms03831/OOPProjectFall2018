#pragma once
#include "DungeonObject.h"

class Keys: public DungeonObject
{
public:
    Keys(){}
    /** Overloaded constructor */
    Keys(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){
                                                           display = false;
                                                       }
    /** Default destructor */
    virtual ~Keys(){}

    /** Inherited pure virtual functions form abstract base class */
    void Interaction();
};

