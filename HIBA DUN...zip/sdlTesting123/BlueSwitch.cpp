#include "BlueSwitch.h"

void BlueSwitch::Interaction()
{
    //
}

