#pragma once
#include <iostream>
#include <cstdlib>
#include <time.h>
#include "DungeonObject.h"
#include "Door.h"
#include "Drawers.h"
#include "Haystack.h"
#include "HealthPowerUp.h"
#include "Keys.h"
#include "Torch.h"
#include "Traps.h"
#include "Weapons.h"
#include "FallingTrap.h"
#include "SpikeTrap.h"
#include "TrapBall.h"
#include "LinkedList.h"
#include "Node.h"
#include "Arrow.h"
#include "RedSwitch.h"
#include "Rack.h"

using namespace std;

/** function prototypes  */
DungeonObject* CreateObjectAt(int, Position, bool, bool);
DungeonObject* placeObject(int, int, DungeonObject*, DungeonObject*);
int Fibonacci(int);
int GetRandomTrap();
int GetTrapPosition(DungeonObject*, DungeonObject*);

/** keeping track of amount of each object*/
int drawerAM, fallingTrapAM, haystackAM, rackAM, healthPowerUpAM, keysAM, spikeTrapAM, torchAM, trapBallAM, redSwitchAM, blueSwitchAM;
int doorAM = drawerAM = fallingTrapAM = haystackAM = rackAM = healthPowerUpAM = keysAM = spikeTrapAM = torchAM = trapBallAM = redSwitchAM = blueSwitchAM;

enum {arrow, door, drawer, fallingTrap, haystack, rack, healthPowerUp, keys, spikeTrap, torch, trapBall, redSwitch, blueSwitch};

int trackObjects = 0;
LinkedList<DungeonObject*> LList;

LinkedList<DungeonObject*> TORCHES;

int inventory = 0;
LinkedList<DungeonObject*> INVENTORY;

/**     game window, renderer*/
bool isRunning;
SDL_Window* window;
SDL_Renderer* renderer;

/**   global positioning/flags   */
int floorLevel = 200;
int SCREEN_WIDTH = 1200;
bool keyPlaced = false;
bool torchPlaced = false;
bool drawerPlaced = false;
bool rackPlaced = false;
bool mouseClicked = false;

int mouse_x;
int mouse_y;
SDL_Rect mouse;

/** creates a floor at a time, takes level of floor as parameter*/
void CreateFLOOR(int floor)
{
    int x1, y1, x2, y2, initialX;
    SDL_Rect r;
    DungeonObject* leftBound;
    DungeonObject* rightBound;
    DungeonObject* temp;

    /**   place doors  &  buttons */
    if (floor % 2 == 0)     // even numbered floor
    {
        temp = CreateObjectAt(door, Position::Set(0,floorLevel), false, false);     // far left door: door closed
        rightBound = CreateObjectAt(door, Position::Set(SCREEN_WIDTH-150, floorLevel), false, true);   // far right door: door open, this is where player shall be placed

        /*  place buttons  */
        r = temp->getDestRect();
        y1 = (r.y+r.h) - (r.h/2);
        x1 = (r.x + r.w) + 10;
        x2 = x1 + 30;
        (CreateObjectAt(redSwitch, Position::Set(x1, y1), false, false))->setControlledObject(temp);
        leftBound = CreateObjectAt(blueSwitch, Position::Set(x2, y1), false, false);
    }
    else
    {
        leftBound = CreateObjectAt(door, Position::Set(0,floorLevel), false, true);     // far left door: door open, this is where player shall be placed
        temp = CreateObjectAt(door, Position::Set(SCREEN_WIDTH-150, floorLevel), false, false);   // far right door: door closed

        /*  place two buttons  */
        r = temp->getDestRect();
        y1 = (r.y+r.h) - (r.h/2);
        x1 = r.x - 25;
        x2 = x1 - 30;
        (CreateObjectAt(redSwitch, Position::Set(x1, y1), false, false))->setControlledObject(temp);
        rightBound = CreateObjectAt(blueSwitch, Position::Set(x2, y1), false, false);
    }

    /**     difficulty level/ probability change for each level*/

    temp = leftBound;

    x1 = leftBound->getDestRect().x + leftBound->getDestRect().w + 50;
    y2 = rightBound->getDestRect().x - 80;
    initialX = x1;
    while (x1 < y2)
    {
        leftBound = placeObject(x1, y1, leftBound, temp);
        // new x bounds
        x1 = (leftBound->getDestRect().x + leftBound->getDestRect().w) + 80;
        if (initialX == x1)
        {
            x1 += 30;
        }
        initialX = x1;
    }

    for (int i = 0; i < Fibonacci(floor+1); i++)
    {
        int t = GetRandomTrap();
        x2 = GetTrapPosition(temp, rightBound);

        if (t == fallingTrap)
            y2 = floorLevel - 50;
        else if (t == trapBall)
            y2 = floorLevel + 100;
        else if (t == spikeTrap)
            y2 = floorLevel + 90;

        CreateObjectAt(t, Position::Set(x2, y2), false, false)->setAnimate(true);
    }

}

DungeonObject* placeObject(int x1, int y1, DungeonObject* leftBound, DungeonObject* temp)
{
    int probability = rand() % 100;

    if (probability > 0 && probability <= 20 && !rackPlaced)
        {
            y1 = floorLevel + 130;
            leftBound = CreateObjectAt(rack, Position::Set(x1, y1), false, false);
            rackPlaced = true;
            torchPlaced = false;
            drawerPlaced = false;

            // now that rack made, place what is on the rack
            int probability2 = rand() % 100;
            if (probability2 > 0 && probability2 <= 20)
            {
                CreateObjectAt(haystack, Position::Set(x1+10, y1-108), false, false);
            }
            else if (probability2 > 50 && probability2 <= 55 && !keyPlaced)
            {
                temp = CreateObjectAt(keys, Position::Set(x1+10, y1-15), false, false);
                temp->setDisplay(true);
                keyPlaced = true;
            }
            else
            {
                temp = CreateObjectAt(healthPowerUp, Position::Set(x1+20, y1-50), false, false);
                temp->setDisplay(true);
            }
        }
        else if (probability > 20 && probability <= 50 && !drawerPlaced)
        {
            leftBound = CreateObjectAt(drawer, Position::Set(x1, y1-50), false, false);
            rackPlaced = false;
            torchPlaced = false;
            drawerPlaced = true;
            // now that drawer made, place what is in the drawer

            int probability2 = rand() % 100;
            probability2 = 70;
            if (probability2 < 10 && !keyPlaced)
            {
                CreateObjectAt(keys, Position::Set(x1, y1), false, false);
                keyPlaced = true;
            }
            else if (probability2 >= 50 && probability2 < 70)
            {
                temp = CreateObjectAt(healthPowerUp, Position::Set(x1, y1), false, false);
                temp->setDisplay(false);
            }
        }
        else if (!torchPlaced)
        {
            rackPlaced = false;
            torchPlaced = true;
            drawerPlaced = false;

            leftBound = CreateObjectAt(torch, Position::Set(x1, floorLevel), false, false);
        }
        return leftBound;
}

DungeonObject* obj;

DungeonObject* CreateObjectAt(int ID, Position p, bool direction, bool doorOpen)
{
    obj = nullptr;
    switch (ID)
    {
    case arrow:
        obj = new Arrow("arrow.png", renderer, Position::Set(0, 0), 300, 275, p, 100, 80);
        obj->setDirection(direction);
        break;

    case door:
        obj = new Door("door.png", renderer, Position::Set(0, 0), 59, 62, p, 150, 190);
        if (doorOpen)
        {
            SDL_Rect s;
            s = obj->getSourceRect();
            s.y = 192;
            obj->setSourceRect(s);
        }
        break;

    case drawer:
        obj = new Drawers("drawersp.png", renderer, Position::Set(0,0), 414, 626, p, 80, 100);
        break;

    case fallingTrap:
        obj = new FallingTrap("fallingtrapsp.png", renderer, Position::Set(0, 0), 134, 88, p, 100, 50);
        break;

    case haystack:
        obj = new Haystack("haystacksp.png", renderer, Position::Set(0, 1518), 648, 508, p, 80, 110);
        break;

    case healthPowerUp:
        obj = new Haystack("HealthPowerUp.png", renderer, Position::Set(0, 0), 210, 211, p, 50, 50);
        break;

    case keys:
        obj = new Keys("KEY.png", renderer, Position::Set(0, 0), 2000, 695, p, 70, 20);
        break;

    case spikeTrap:
        obj = new SpikeTrap("spikeyy.png", renderer, Position::Set(0, 0), 181, 177, p, 80, 80);
        break;

    case torch:
        obj = new Torch("torchsp.png", renderer, Position::Set(0, 0), 250, 701, p, 30, 80);
        TORCHES.push(torchAM, obj);
        torchAM++;
        break;

    case trapBall:
        obj = new TrapBall("dungeonball.png", renderer, Position::Set(0,0), 173, 167, p, 90, 90);
        break;

    case redSwitch:
        obj = new RedSwitch("redButton.png", renderer, Position::Set(0, 0), 600, 600, p, 20, 20);
        break;

    case blueSwitch:
        obj = new RedSwitch("bluebutton.png", renderer, Position::Set(0,0), 720, 720, p, 25, 25);
        break;

    case rack:
        obj = new Rack("rack.png", renderer, Position::Set(0, 0), 414, 82, p, 100, 10);
        break;

    default:
        break;
    }
    LList.push(trackObjects, obj);
    obj->setID(ID);
    trackObjects++;
    return obj;
}

void init(const char* title, Position pos, int width, int height, bool fullscreen)
{
    int flags = 0;
    if (fullscreen)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }

    if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
    {
        cout << "SDL INITIALIZED." << endl;
        window = SDL_CreateWindow(title, pos.x, pos.y, width, height, flags);
        if (window)
        {
            cout << "Window created." << endl;
        }

        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 5);
            cout << "Renderer created." << endl;
        }
        isRunning = true;
    }
    else
    {
        isRunning = false;
    }

    CreateFLOOR(3);
}

int GetRandomTrap()
{
    int TRAPS[3] = {fallingTrap, trapBall, spikeTrap};
    int getRand = rand() % 3;
    return TRAPS[getRand];
}

int GetTrapPosition(DungeonObject* leftBound, DungeonObject* rightBound)
{
    int bounds_start = leftBound->getPosition().x + leftBound->getDestRect().w;
    int bounds_end = rightBound->getPosition().x;

    cout << bounds_start << " " << bounds_end << endl;

    /** worst case scenario, no object placed and left bound moved 30 pixels in each iteration, total distance: */
    int bounds = ( SCREEN_WIDTH - (bounds_start + rightBound->getDestRect().w) );
    int pos = rand() % bounds;

    if (pos < bounds_start)
        pos +=bounds_start + 250;
    else if (pos > bounds_end)
        pos -= bounds_end;

    cout << pos << endl;
    return pos;
}

bool running()
{
    return isRunning;
}

void ClickEvents()
{
    for (int i = 0; i < trackObjects; i++)
    {
        obj = LList.getElement(i);
        if (obj->getDisplay() && obj->isCharacterInteracting(mouse))
        {
            int prob;
            switch (obj->getID())
            {
            case blueSwitch:

                prob = rand() % torchAM;
                obj = TORCHES.getElement(prob);
                obj->Interaction();

                break;

            case redSwitch:
                obj->Interaction();

                break;

            case healthPowerUp:
                obj->setDisplay(false);
                LList.pop(i);
                trackObjects--;

                break;

            case keys:
                obj->setDisplay(false);
                LList.pop(i);
                trackObjects--;

            case haystack:
                obj->Interaction();

                break;

            default:
                break;
            }
        }

    }
}

void handleEvents()
{
    SDL_Event event;
    SDL_PollEvent(&event);
    switch (event.type)
    {
    case SDL_QUIT:
        isRunning = false;
        break;
    case SDL_MOUSEMOTION:
        SDL_GetMouseState( &mouse_x, &mouse_y );
    case SDL_MOUSEBUTTONDOWN:
        mouseClicked = false;
        mouse.x = mouse_x;
        mouse.y = mouse_y;
        break;
    case SDL_MOUSEBUTTONUP:
        mouseClicked = true;        // mouse released
        ClickEvents();
        break;
    default:
        break;
    }
}

int Fibonacci(int position)
{
    int i = 1;
    int sum = i;
    int first = 0;
    int second = 1;

    for (; i <= position; i++)
    {
        if (i <= 1)
            sum = i;
        else
        {
            sum = first + second;
            first = second;
            second = sum;
        }
    }

    return sum;
}

void render()
{
    SDL_RenderClear(renderer);

    for (int i = 0; i < trackObjects; i++)
    {
        if ((LList.getElement(i))->getDisplay())
            (LList.getElement(i))->render();
    }

    SDL_RenderPresent(renderer);
}

void update()
{
    for (int i = 0; i < trackObjects; i++)
    {
        if ((LList.getElement(i))->getAnimate())
            (LList.getElement(i))->update();
        if ((LList.getElement(i))->getGoDestroy())
        {
            LList.pop(i);
            trackObjects--;
        }
    }
}

void clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();

    // delete all dynamically allocated objects in llist?

    cout << "All memory deallocated" << endl;
}
