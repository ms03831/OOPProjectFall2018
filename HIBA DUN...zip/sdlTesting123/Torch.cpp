#include "Torch.h"
#include "TextureManager.h"

void Torch::Interaction()
{
    SDL_Texture* t = TextureManager::LoadTexture("explosion.png", getRenderer());
    setTexture(t);

    SDL_Rect src;
    src.x = 0;
    src.y = 0;
    src.w = 79;
    src.h = 79;
    setSourceRect(src);

    SDL_Rect dst = getDestRect();
    dst.x -=50;
    dst.y -=50;
    dst.w = 210;
    dst.h = 210;
    setDestRect(dst);

    explosionStat = true;
    runTime = 0;
}

void Torch::update()
{
    if (explosionStat)
    {
        Explode();
    }
    else
    {
        if (getFrameRate() % 120 == 0)
        {
            SDL_Rect r;
            r = getSourceRect();
            int index = (int)runTime;
            r.y = sprites[index];
            setSourceRect(r);
            runTime++;
            if (runTime >= spritesNumber)
                runTime = 0;
        }
    }
}

void Torch::render()
{
    SDL_Rect src = getSourceRect();
    SDL_Rect dest = getDestRect();
    SDL_RenderCopy(getRenderer(), getTexture(), &src, &dest);
    setFrameRate(getFrameRate() + 1);
}

int sp = 100;       // speed of animation

void Torch::Explode()
{
    if (getFrameRate() % sp == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        if (runTime < 8)
        {
            r.x += r.w;
            setSourceRect(r);
        }
        else
        {
            if (r.y < 474)
            {
                r.y += r.h;
                r.x = 0;
                setSourceRect(r);
                sp += 5;
            }
            else
            {
                r.y = 0;
                setSourceRect(r);
                explosionStat = false;
                goDestroy = true;
            }
        }
        runTime++;
    }
}
