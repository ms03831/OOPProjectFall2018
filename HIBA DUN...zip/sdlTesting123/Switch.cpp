#include "Switch.h"

void Switch::Interaction()
{

}
