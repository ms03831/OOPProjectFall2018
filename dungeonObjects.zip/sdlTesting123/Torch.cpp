#include "Torch.h"

bool Torch::isCharacterInteracting(Position pos)
{
    return true;
}

void Torch::Interaction()
{

}

void Torch::update()
{
    if (getFrameRate() % 120 == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        int index = (int)runTime;
        r.y = sprites[index];
        setSourceRect(r);
        runTime++;
        if (runTime >= spritesNumber)
            runTime = 0;
    }
}
