#include "Traps.h"

bool Traps::isCharacterInteracting(Position)
{
    return false;
}

void Traps::Interaction()
{
    //
}
