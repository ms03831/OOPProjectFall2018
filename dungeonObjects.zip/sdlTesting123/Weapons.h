#pragma once
#include "Game.h"

class Weapons: public DungeonObject
{
public:
    /** Overloaded constructor */
    Weapons(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){}
    /** Default destructor */
    virtual ~Weapons(){}

    /** Inherited pure virtual functions form abstract base class */
    bool isCharacterInteracting(Position characterPos);
    void Interaction();
};
