#pragma once
#include "Game.h"

class Door: public DungeonObject
{
public:
    /** Overloaded constructor */
    Door(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight)
    {
        spritesNumber = 4;
        sprites = new int[spritesNumber];

        sprites[0] = 0;
        sprites[1] = 64;
        sprites[2] = 128;
        sprites[3] = 192;

        display = true;
    }
    /** Default destructor */
    virtual ~Door(){}

    void update();

    /** Inherited pure virtual functions form abstract base class */
    bool isCharacterInteracting(Position characterPos);
    void Interaction();
};
