#pragma once
#include "Traps.h"

class EnemyTrapExplosion: public Traps
{
public:
    EnemyTrapExplosion(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Traps(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight){}
    virtual ~EnemyTrapExplosion(){}

    void update();

    bool isCharacterInteracting(Position pos);
    void Interaction();
};
