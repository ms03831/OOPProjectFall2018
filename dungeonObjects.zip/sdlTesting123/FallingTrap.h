#pragma once
#include "Traps.h"

class FallingTrap: public Traps
{
public:
    /** Overloaded constructor */
    FallingTrap(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): Traps(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight)
    {
        spritesNumber = 2;
        sprites = new int[spritesNumber];

        sprites[0] = 0;
        sprites[1] = 177;
    }
    /** Default destructor */
    virtual ~FallingTrap(){}

    void update();
    void Fall();
    void FallBack();
    /** Inherited pure virtual functions form abstract base class */
    bool isCharacterInteracting(Position pos);
    void Interaction();
};
