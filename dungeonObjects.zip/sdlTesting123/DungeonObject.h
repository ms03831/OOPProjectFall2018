#pragma once
#include "Game.h"
#include <iostream>
#include <cstdlib>

// base class for dungeon objects
class DungeonObject
{
private:
    Position pos;       // position of object

    Uint32 frameRate;
    SDL_Texture* texture;
    SDL_Rect sourceRect, destRect;
    SDL_Renderer* renderer;
protected:
    int* sprites;
    int spritesNumber;
    double runTime;
    bool display;
    bool animate;
    bool direction;     // true means right and vice versa

    int startAnimation;
public:
    DungeonObject(){}
    /** Overloaded constructor */
    DungeonObject(const char* filename, SDL_Renderer* ren, Position sourcePos,
                  int sourceWidth, int sourceHeight, Position destPos, int destWidth, int destHeight);
    /** Default destructor */
    virtual ~DungeonObject(){}

    virtual void update(){std::cout << "base update\n"; }
    virtual void render();

    /** Pure virtual functions */
    virtual bool isCharacterInteracting(Position characterPos) = 0;   // check whether player is behind/inside object: will be different for different objects
    virtual void Interaction() = 0;         // if isCharacterInteracting(Position) returns true, this function determines nature of interaction

    /** Getters/Setters */
    SDL_Texture* getTexture();
    SDL_Rect getSourceRect();
    SDL_Rect getDestRect();
    SDL_Renderer* getRenderer();
    Position getPosition();
    Uint32 getFrameRate();
    void setFrameRate(Uint32);
    void setPosition(Position);
    void setSourceRect(SDL_Rect);
    void setDestRect(SDL_Rect);
    int getSpriteAt(int);
    bool getDisplay();
    void setDisplay(bool);
    bool getAnimate();
    void setAnimate(bool);
    void setRunTime(double);
    double getRunTime();
    void setDirection(bool);
    Uint32 getStartAnimation();
    void setStartAnimation(Uint32);
};



