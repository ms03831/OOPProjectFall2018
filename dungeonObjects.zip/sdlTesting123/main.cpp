#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include "Position.h"
#include "LoadGame.h"

using namespace std;

int main( int argc, char* args[] )
{
    srand(time(NULL));
    init("New Game", Position::Set(SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED), 1200, 600, false);

    while (running())
    {
        render();
        update();
        handleEvents();
    }

    clean();

    /*LinkedList<int> l;
    l.push(0, 1);
    l.push(1, 2);
    l.push(2, 3);
    l.pop(0);
    Node<int>* head = l.getHead();
    cout << endl;
    while (head != NULL)
    {
        cout << head->data << endl;
        head = head->next;
    }
*/

    getch();
    return 0;
}
