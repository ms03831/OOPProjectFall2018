#pragma once
#include "Game.h"

class Torch: public DungeonObject
{
public:
    /** Overloaded constructor */
    Torch(const char* filename, SDL_Renderer* ren,
         Position sourcePos, int sourceWidth, int sourceHeight, Position destPos,
         int destWidth, int destHeight): DungeonObject(filename, ren, sourcePos, sourceWidth, sourceHeight,
                                                       destPos, destWidth, destHeight)
    {
        spritesNumber = 2;
        sprites = new int[spritesNumber];

        sprites[0] = 0;
        sprites[1] = 740;

        display = true;
        animate = true;
    }
    /** Default destructor */
    virtual ~Torch(){}
    void update();
    void Explosion();
    /** Inherited pure virtual functions form abstract base class */
    bool isCharacterInteracting(Position characterPos);
    void Interaction();
};
