#include "EnemyTrapExplosion.h"

bool EnemyTrapExplosion::isCharacterInteracting(Position)
{
    return false;
}

void EnemyTrapExplosion::Interaction()
{
    //
}

int sp = 100;       // speed of animation

void EnemyTrapExplosion::update()
{
    if ( getFrameRate() % sp == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        if (runTime < 8)
        {
            r.x+=r.w;
            setSourceRect(r);
        }
        else
        {
            if (r.y < 474)
            {
                r.y+=r.h;
                r.x = 0;
                setSourceRect(r);
                sp += 5;
            }
            else
            {
                r.y = 0;
                setSourceRect(r);
                // sprite sheet completed
                animate = false;
                display = false;
            }
        }
        runTime++;
    }
}
