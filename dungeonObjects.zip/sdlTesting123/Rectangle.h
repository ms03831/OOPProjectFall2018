#pragma once

class Rectangle
{
public:
    int h, w;
    int x, y;

    /** Overloaded constructor */
    Rectangle(int w, int h, int x, int y);
    /** Default destructor */
    virtual ~Rectangle();

    /** Static function to create and return a rectangle in place */
    static Rectangle Set(int w, int h, int x, int y);
};
