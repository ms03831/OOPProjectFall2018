#include "Haystack.h"

bool Haystack::isCharacterInteracting(Position pos)
{
    return true;
}

void Haystack::Interaction()
{
    //
}

void Haystack::update()
{
    if (runTime==spritesNumber)
        animate = false;

    if (getFrameRate() % 140 == 0)
    {
        SDL_Rect r;
        r = getSourceRect();
        r.y = sprites[(int)runTime];
        setSourceRect(r);
        runTime++;
    }
}
