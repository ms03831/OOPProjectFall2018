#pragma once
#include <iostream>
#include <cstdlib>
#include <time.h>
#include "DungeonObject.h"
#include "Door.h"
#include "Drawers.h"
#include "Haystack.h"
#include "HealthPowerUp.h"
#include "Keys.h"
#include "Torch.h"
#include "Traps.h"
#include "Weapons.h"
#include "FallingTrap.h"
#include "SpikeTrap.h"
#include "TrapBall.h"
#include "EnemyTrapExplosion.h"
#include "LinkedList.h"
#include "Node.h"
#include "Arrow.h"
#include "RedSwitch.h"
#include "Rack.h"

using namespace std;

// function prototypes
DungeonObject* CreateObjectAt(int, Position, bool, bool);
DungeonObject* placeObject(int, int, DungeonObject*, DungeonObject*);

enum {arrow, door, drawer, explosion, fallingTrap, haystack, rack, healthPowerUp, keys, spikeTrap, torch, trapBall, redSwitch};

int trackObjects = 0;
LinkedList<DungeonObject*> LList;

/**     game window, renderer*/
bool isRunning;
SDL_Window* window;
SDL_Renderer* renderer;

/**   global positioning/flags   */
int floorLevel = 250;
bool keyPlaced = false;
bool torchPlaced = false;
bool drawerPlaced = false;
bool rackPlaced = false;

/** creates a floor at a time, takes level of floor as parameter*/
void CreateFLOOR(int floor)
{
    int x1, y1, x2, y2;
    SDL_Rect r;
    DungeonObject* leftBound;
    DungeonObject* rightBound;
    DungeonObject* temp;

    /**   place doors  &  buttons */
    if (floor % 2 == 0)     // even numbered floor
    {
        temp = CreateObjectAt(door, Position::Set(0,floorLevel), false, false);     // far left door: door closed
        rightBound = CreateObjectAt(door, Position::Set(1141, floorLevel), false, true);   // far right door: door open, this is where player shall be placed

        /*  place buttons  */
        r = temp->getDestRect();
        y1 = (r.y+r.h) - (r.h/2);
        x1 = (r.x + r.w) + 10;
        x2 = x1 + 30;
        CreateObjectAt(redSwitch, Position::Set(x1, y1), false, false);
        leftBound = CreateObjectAt(redSwitch, Position::Set(x2, y1), false, false);
    }
    else
    {
        leftBound = CreateObjectAt(door, Position::Set(0,floorLevel), false, true);     // far left door: door open, this is where player shall be placed
        temp = CreateObjectAt(door, Position::Set(1141, floorLevel), false, false);   // far right door: door closed

        /*  place two buttons  */
        r = temp->getDestRect();
        y1 = (r.y+r.h) - (r.h/2);
        x1 = r.x - 25;
        x2 = x1 - 30;
        CreateObjectAt(redSwitch, Position::Set(x1, y1), false, false);
        rightBound = CreateObjectAt(redSwitch, Position::Set(x2, y1), false, false);
    }


    /**     difficulty level/ probability change for each level*/
    switch (floor)
    {
    case 1:
        x1 = leftBound->getDestRect().x + leftBound->getDestRect().w + 50;
        y2 = rightBound->getDestRect().x - 80;
        cout << x1 << endl<<y2;
        while (x1 < y2)
        {
            leftBound = placeObject(x1, y1, leftBound, temp);
            // new x bounds
            x1 = leftBound->getDestRect().x + leftBound->getDestRect().w + 80;
            cout << "\t\tx1:" << x1 << endl;
        }

        break;
    case 2:
        break;
    case 3:
        break;
    case 4:
        break;
    case 5:
        break;
    default:
        break;
    }
}

DungeonObject* placeObject(int x1, int y1, DungeonObject* leftBound, DungeonObject* temp)
{
    int probability = rand() % 100;

    if (probability > 0 && probability <= 20 && !rackPlaced)
        {
            cout << "rack placed\n" << x1;
            y1 = floorLevel + 130;
            leftBound = CreateObjectAt(rack, Position::Set(x1, y1), false, false);
            rackPlaced = true;
            torchPlaced = false;
            drawerPlaced = false;

            // now that rack made, place what is on the rack
            int probability2 = rand() % 100;
            if (probability2 > 0 && probability2 <= 20)
            {
                CreateObjectAt(haystack, Position::Set(x1+10, y1-108), false, false);
                cout << "haystack on rack\n" << x1;
            }
            else if (probability2 > 50 && probability2 <= 60 && !keyPlaced)
            {
                cout << "key on rack\n" << x1;
                temp = CreateObjectAt(keys, Position::Set(x1+10, y1-15), false, false);
                temp->setDisplay(true);
                keyPlaced = true;
            }
            else
            {
                cout << "health on rack\n" << x1;
                temp = CreateObjectAt(healthPowerUp, Position::Set(x1+20, y1-50), false, false);
                temp->setDisplay(true);
            }
        }
        else if (probability > 20 && probability <= 50 && !drawerPlaced)
        {
            leftBound = CreateObjectAt(drawer, Position::Set(x1, y1-50), false, false);
            cout << "drawer created\n" << x1;
            rackPlaced = false;
            torchPlaced = false;
            drawerPlaced = true;
            // now that drawer made, place what is in the drawer

            int probability2 = rand() % 100;
            probability2 = 70;
            if (probability2 < 10 && !keyPlaced)
            {
                cout << "key in drawer\n" << x1;
                CreateObjectAt(keys, Position::Set(x1, y1), false, false);
                keyPlaced = true;
            }
            else if (probability2 >= 50 && probability2 < 70)
            {
                cout << "health on drawer\n" << x1;
                temp = CreateObjectAt(healthPowerUp, Position::Set(x1, y1), false, false);
                temp->setDisplay(false);
            }
        }
        else if (!torchPlaced)
        {
            cout << "torch created\n" << x1 << endl;
            rackPlaced = false;
            torchPlaced = true;
            drawerPlaced = false;

            leftBound = CreateObjectAt(torch, Position::Set(x1, floorLevel), false, false);
        }

        cout << "\t\t end of func \n\n";
        return leftBound;
}

DungeonObject* obj;

DungeonObject* CreateObjectAt(int ID, Position p, bool direction, bool doorOpen)
{
    obj = nullptr;
    switch (ID)
    {
    case arrow:
        obj = new Arrow("arrow.png", renderer, Position::Set(0, 0), 300, 275, p, 100, 80);
        obj->setDirection(direction);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case door:
        obj = new Door("door.png", renderer, Position::Set(0, 0), 59, 62, p, 150, 190);
        if (doorOpen)
        {
            SDL_Rect s;
            s = obj->getSourceRect();
            s.y = 192;
            obj->setSourceRect(s);
        }
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case drawer:
        obj = new Drawers("drawersp.png", renderer, Position::Set(0,0), 414, 626, p, 80, 100);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case explosion:
        obj = new EnemyTrapExplosion("explosion.png", renderer, Position::Set(0, 0), 79, 79, p, 210, 210);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case fallingTrap:
        obj = new FallingTrap("fallingtrapsp.png", renderer, Position::Set(0, 0), 134, 88, p, 100, 50);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case haystack:
        obj = new Haystack("haystacksp.png", renderer, Position::Set(0, 1518), 648, 508, p, 80, 110);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case healthPowerUp:
        obj = new Haystack("HealthPowerUp.png", renderer, Position::Set(0, 0), 210, 211, p, 50, 50);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case keys:
        obj = new Keys("KEY.png", renderer, Position::Set(0, 0), 2000, 695, p, 70, 20);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case spikeTrap:
        obj = new SpikeTrap("spikeyy.png", renderer, Position::Set(0, 0), 181, 177, p, 80, 80);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case torch:
        obj = new Torch("torchsp.png", renderer, Position::Set(0, 0), 250, 701, p, 30, 80);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case trapBall:
        obj = new TrapBall("dungeonball.png", renderer, Position::Set(0,0), 173, 167, p, 90, 90);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case redSwitch:
        obj = new RedSwitch("redButton.png", renderer, Position::Set(0, 0), 600, 600, p, 20, 20);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    case rack:
        obj = new Rack("rack.png", renderer, Position::Set(0, 0), 414, 82, p, 100, 10);
        LList.push(trackObjects, obj);
        trackObjects++;
        break;

    default:
        break;
    }
    return obj;
}

void init(const char* title, Position pos, int width, int height, bool fullscreen)
{
    int flags = 0;
    if (fullscreen)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }

    if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
    {
        cout << "SDL INITIALIZED." << endl;
        window = SDL_CreateWindow(title, pos.x, pos.y, width, height, flags);
        if (window)
        {
            cout << "Window created." << endl;
        }

        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 5);
            cout << "Renderer created." << endl;
        }
        isRunning = true;
    }
    else
    {
        isRunning = false;
    }

    CreateFLOOR(1);
}

bool running()
{
    return isRunning;
}

void handleEvents()
{
    SDL_Event event;
    SDL_PollEvent(&event);
    switch (event.type)
    {
    case SDL_QUIT:
        isRunning = false;
        break;
    default:
        break;
    }
}

void render()
{
    SDL_RenderClear(renderer);

    for (int i = 0; i < trackObjects; i++)
    {
        if ((LList.getElement(i))->getDisplay())
            (LList.getElement(i))->render();
    }

    SDL_RenderPresent(renderer);
}

bool checkCollision(SDL_Rect firstObj, SDL_Rect secondObj)
{
    //The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    //Calculate the sides of rect firstObj
    leftA = firstObj.x;
    rightA = firstObj.x + firstObj.w;
    topA = firstObj.y;
    bottomA = firstObj.y + firstObj.h;

    //Calculate the sides of rect secondObj
    leftB = secondObj.x;
    rightB = secondObj.x + secondObj.w;
    topB = secondObj.y;
    bottomB = secondObj.y + secondObj.h;

    //If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        return false;
    }

    if( topA >= bottomB )
    {
        return false;
    }

    if( rightA <= leftB )
    {
        return false;
    }

    if( leftA >= rightB )
    {
        return false;
    }

    //If none of the sides from firstObj are outside secondObj
    return true;
}

void update()
{
    for (int i = 0; i < trackObjects; i++)
    {
        if ((LList.getElement(i))->getAnimate())
            (LList.getElement(i))->update();
    }
}

void clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();

    // delete all dynamically allocated objects in llist?

    cout << "All memory deallocated" << endl;
}
