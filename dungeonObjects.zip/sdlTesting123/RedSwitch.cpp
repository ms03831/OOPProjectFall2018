#include "RedSwitch.h"

bool RedSwitch::isCharacterInteracting(Position)
{
    return false;
}

void RedSwitch::Interaction()
{
    //
}
