#include "Rack.h"

bool Rack::isCharacterInteracting(Position)
{
    return false;
}

void Rack::Interaction()
{
    //
}
