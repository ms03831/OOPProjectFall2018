#include "Rectangle.h"

Rectangle::Rectangle(int w, int h, int x, int y)
{
    this->h = h;
    this->w = w;
    this->x = x;
    this->y = y;
}

Rectangle Rectangle::Set(int w, int h, int x, int y)
{
    Rectangle rect(w, h, x, y);
    return rect;
}

Rectangle::~Rectangle()
{
    //
}
